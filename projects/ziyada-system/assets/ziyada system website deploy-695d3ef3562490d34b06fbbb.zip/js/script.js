const translations = {
    ar: {
        "nav.home": "الرئيسية", "nav.about": "من نحن", "nav.why": "لماذا زيادة", "nav.services": "خدماتنا", "nav.cases": "قصص النجاح", "nav.blog": "المدونة", "nav.contact": "تواصل",
        "cta.book": "حجز استشارة", "cta.meeting": "حجز جلسة استراتيجية", "cta.proposal": "طلب عرض سعر",
        "hero.title": "أنظمة نمو متكاملة", "hero.subtitle": "نساعدك في بناء منظومة متكاملة تربط التسويق بالمبيعات بالنتائج. منهجيات تنفيذية دقيقة.",
        "hero.trust": "نطبق منهجيات مجربة - لا شعارات رنانة - نتائج حقيقية",
        "services.title": "خدمات زيادة للأنظمة", "services.intro": "نقدم حلولاً عملية تشمل تصميم الأنظمة التشغيلية وتطوير البنية الرقمية.",
        "services.growth": "استراتيجية النمو", "services.funnels": "مسارات التحويل", "services.crm": "أنظمة CRM", "services.ads": "إدارة الإعلانات", "services.data": "تحليل البيانات", "services.auto": "أتمتة العمليات",
        "about.title": "من نحن",
        "about.p1": "شركة زيادة للأنظمة شركة متخصصة في تصميم وبناء الأنظمة التشغيلية والرقمية التي تساعد الشركات على العمل بوضوح وكفاءة واستقرار.",
        "about.p2": "نعمل مع الجهات التي تواجه تعقيدًا في العمليات، أو تشتتًا في الأدوات، أو صعوبة في الربط بين فرق العمل والتقنية والبيانات. دورنا هو تحويل هذه الفوضى إلى أنظمة واضحة قابلة للإدارة والتطوير.",
        "about.p3": "نؤمن أن نجاح أي مؤسسة يبدأ من بنية داخلية صحيحة، لذلك نركز على بناء منظومات متكاملة تخدم العمل اليومي وتدعم اتخاذ القرار على المدى الطويل.",
        "about.vision_title": "رؤيتنا", "about.vision_desc": "تمكين الشركات من امتلاك أنظمة نمو واضحة، قابلة للإدارة، وقائمة على الأرقام لا الافتراضات.",
        "about.method_title": "منهجيتنا", "about.method_desc": "نحلّل، نُصمّم، نُنفّذ، ثم نُحسّن بشكل مستمر، مع ربط كل خطوة بمؤشرات أداء واضحة.",
        "why.title": "لماذا زيادة؟", "why.intro": "تعتمد شركة زيادة على منظومة خبرات متقدمة في تطوير الأعمال وبناء أنظمة النمو.",
        "why.accreditations_title": "الاعتمادات المهنية", "why.capabilities_title": "قدراتنا التخصصية",
        "why.operational_title": "قدراتنا التشغيلية", "why.unique_title": "ما يميزنا",
        "why.conclusion": "تعتمد شركة زيادة في جميع خدماتها على خبرات عملية ومنهجيات مثبتة.",
        "meeting.title": "حجز جلسة استراتيجية", "proposal.title": "طلب عرض سعر", "contact.title": "تواصل معنا", "contact.desc": "للاستفسارات العامة، يرجى ملء النموذج.",
        "form.name": "الاسم الكامل", "form.email": "البريد الإلكتروني", "form.company": "اسم الشركة", "form.phone": "رقم الجوال",
        "form.size": "حجم الشركة", "form.industry": "القطاع", "form.budget": "الميزانية المتوقعة", "form.timeline": "الإطار الزمني",
        "form.challenge": "التحدي الحالي", "form.services_needed": "الخدمات المطلوبة", "form.consent": "أوافق على سياسة الخصوصية",
        "form.submit_meeting": "تأكيد الحجز", "form.submit_proposal": "إرسال الطلب",
        "thanks.title": "شكراً لك!", "thanks.msg": "تم استلام طلبك بنجاح.",
        "footer.desc": "تصميم وبناء الأنظمة التشغيلية والرقمية للشركات الطموحة."
    },
    en: {
        "nav.home": "Home", "nav.about": "Who We Are", "nav.why": "Why Ziyada", "nav.services": "Services", "nav.cases": "Case Studies", "nav.blog": "Insights", "nav.contact": "Contact",
        "cta.book": "Book Consultation", "cta.meeting": "Strategic Session", "cta.proposal": "Request Proposal",
        "hero.title": "Integrated Growth Systems, Not Quick Fixes", "hero.subtitle": "We help you build an integrated ecosystem connecting marketing, sales, and results. Proprietary execution methodologies.",
        "hero.trust": "Proven Methodologies - No Fluff - Real Results",
        "services.title": "Our Solutions", "services.intro": "We provide practical solutions including operational system design, digital infrastructure development, and data systems.",
        "services.growth": "Growth Strategy", "services.funnels": "Conversion Funnels", "services.crm": "CRM Design", "services.ads": "Ad Management", "services.data": "Data Analytics", "services.auto": "Automation",
        "about.title": "Who We Are",
        "about.p1": "Ziyada Systems specializes in designing and building operational and digital systems that help companies operate with clarity, efficiency, and stability.",
        "about.p2": "We work with entities facing operational complexity, tool fragmentation, or difficulty connecting teams, tech, and data. Our role is to transform this chaos into manageable, scalable systems.",
        "about.p3": "We believe organizational success starts with a correct internal structure, focusing on building integrated ecosystems that serve daily operations and support long-term decision making.",
        "about.vision_title": "Our Vision", "about.vision_desc": "Empowering companies to own clear, manageable growth systems based on numbers, not assumptions.",
        "about.method_title": "Our Methodology", "about.method_desc": "We analyze, design, execute, and continuously optimize, linking every step to clear KPIs.",
        "why.title": "Why Ziyada?", "why.intro": "Ziyada Systems relies on advanced expertise in business development and growth systems.",
        "why.accreditations_title": "Professional Accreditations", "why.capabilities_title": "Specialized Capabilities",
        "why.operational_title": "Operational Capabilities", "why.unique_title": "Why Us",
        "why.conclusion": "Ziyada Systems relies on practical expertise and proven methodologies.",
        "meeting.title": "Book Strategy Session", "proposal.title": "Request Proposal", "contact.title": "Get in Touch", "contact.desc": "For general inquiries, please fill out the form below.",
        "form.name": "Full Name", "form.email": "Work Email", "form.company": "Company Name", "form.phone": "Phone Number",
        "form.size": "Company Size", "form.industry": "Industry", "form.budget": "Expected Budget", "form.timeline": "Timeline",
        "form.challenge": "Current Challenge", "form.services_needed": "Services Needed", "form.consent": "I agree to the privacy policy",
        "form.submit_meeting": "Confirm Booking", "form.submit_proposal": "Submit Request",
        "thanks.title": "Thank You!", "thanks.msg": "Your request has been received successfully.",
        "footer.desc": "Designing and building operational and digital systems for ambitious companies."
    }
};

/* --- CONTENT DATA --- */
const whyData = {
    accreditations: {
        ar: [
            'اعتماد مهني في تحليل البيانات واستخدامها في دعم القرار',
            'اعتماد متقدم في تصميم أنظمة الإنتاجية وإدارة سير العمل',
            'تأهيل مهني في التسويق الرقمي متعدد القنوات',
            'اعتماد في إدارة المشاريع وفق منهجيات احترافية',
            'خبرة معتمدة في بناء أنظمة نمو قائمة على الأداء',
            'كفاءة عالية في العمل ضمن أطر تنظيمية وتشغيلية معقدة'
        ],
        en: [
            'Advanced accreditation in Productivity Systems & Workflow Design',
            'Professional qualification in Multi-Channel Digital Marketing',
            'Project Management accreditation using professional methodologies',
            'Certified expertise in building Performance-Based Growth Systems',
            'High proficiency in working within complex regulatory and operational frameworks'
        ]
    },
    capabilities: {
        ar: [
            'تطوير استراتيجيات نمو وتسويق مرتبطة بالأهداف المؤسسية',
            'بناء أنظمة توليد عملاء وربطها بمسارات بيع واضحة',
            'تصميم وإدارة مسارات التحويل من الوعي حتى الإغلاق',
            'تحليل الأداء التسويقي والتشغيلي وتحويل البيانات إلى قرارات',
            'بناء لوحات مؤشرات أداء تدعم القيادات في اتخاذ القرار',
            'تحسين كفاءة الإنفاق وتحقيق أفضل عائد على الاستثمار',
            'إدارة الحملات وتحسين أدائها بشكل مستمر',
            'أتمتة العمليات لرفع الكفاءة وتقليل الهدر التشغيلي'
        ],
        en: [
            'Developing growth strategies aligned with corporate goals',
            'Building lead generation systems linked to clear pipelines',
            'Designing and managing conversion funnels',
            'Analyzing marketing/operational performance for decisions',
            'Building KPI dashboards for executive leadership',
            'Optimizing spend efficiency and maximizing ROI',
            'Continuous campaign management and optimization',
            'Process automation to increase efficiency'
        ]
    },
    operational: {
        ar: [
            'قيادة فرق متعددة التخصصات ضمن أطر أداء واضحة',
            'تصميم أنظمة إنتاجية تقلل التداخل وتزيد الوضوح',
            'إدارة مسارات العمل ومتابعة التنفيذ بدقة',
            'إعداد تقارير تنفيذية مختصرة تخدم صناع القرار',
            'إدارة المخاطر التشغيلية ودعم الاستدامة'
        ],
        en: [
            'Leading cross-functional teams within clear frameworks',
            'Designing productivity systems that reduce overlap',
            'Managing workflows and tracking execution precisely',
            'Preparing concise executive reports for decision makers',
            'Managing operational risks and supporting sustainability'
        ]
    },
    unique: {
        ar: [
            'خبرة مؤسسية ناتجة عن تطبيقات عملية وليست نظرية',
            'ربط مباشر بين الاستراتيجية والتنفيذ والأثر',
            'تركيز على بناء أنظمة قابلة للقياس والتوسع',
            'منهجية واضحة تعتمد على البيانات لا الافتراضات',
            'شراكة تنفيذية طويلة المدى مع عملائنا'
        ],
        en: [
            'Institutional expertise from practical application',
            'Direct link between strategy, execution, and impact',
            'Focus on building measurable and scalable systems',
            'Clear methodology based on data, not assumptions',
            'Long-term executive partnership with our clients'
        ]
    }
};

const casesData = [
    {
        id: 1,
        titleAr: "تحول رقمي لشركة لوجستية كبرى",
        titleEn: "Digital Transformation for Major Logistics Firm",
        descAr: "نجحنا في تقليل التكاليف التشغيلية بنسبة 30% من خلال أتمتة العمليات وربط الأنظمة.",
        descEn: "We successfully reduced operational costs by 30% through process automation and system integration.",
        metrics: ["30% Cost Reduction", "2x Faster Processing", "Zero Data Loss"],
        contentAr: "قام فريق زيادة بتحليل البنية التحتية القديمة للعميل، وتصميم نظام مركزي يربط بين إدارة المخزون والمبيعات والشحن. تم استبدال العمليات اليدوية بأنظمة آلية دقيقة.",
        contentEn: "Ziyada team analyzed the client's legacy infrastructure and designed a centralized system connecting inventory, sales, and shipping. Manual processes were replaced with precise automated systems."
    },
    {
        id: 2,
        titleAr: "زيادة مبيعات متجر إلكتروني بنسبة 200%",
        titleEn: "200% Sales Increase for E-commerce Store",
        descAr: "إعادة تصميم مسارات التحويل (Funnels) وتحسين تجربة المستخدم لتحقيق نمو قياسي في المبيعات.",
        descEn: "Redesigning conversion funnels and improving UX to achieve record sales growth.",
        metrics: ["200% Sales Growth", "45% Higher AOV", "15% Conversion Rate"],
        contentAr: "تم التركيز على تحليل سلوك العملاء وتحديد نقاط التسرب في رحلة الشراء. قمنا بتطوير استراتيجية تسويق أداء (Performance Marketing) متكاملة مع تحسينات جوهرية في واجهة المتجر.",
        contentEn: "We focused on analyzing customer behavior and identifying drop-off points in the buying journey. We developed an integrated performance marketing strategy with core improvements to the store interface."
    }
];

const blogData = [
    {
        id: 1,
        date: '2026-01-02',
        titleAr: 'لماذا تفشل معظم استراتيجيات النمو؟',
        titleEn: 'Why Most Growth Strategies Fail?',
        excerptAr: 'تحليل عميق للأسباب الجذرية لفشل الشركات في تحقيق نمو مستدام، وكيفية تجنب فخ "الحلول السريعة".',
        excerptEn: 'Deep dive into root causes of growth failure and how to avoid the "quick fix" trap.',
        contentAr: `
            <p>في عالم مليء بالتغيرات المتسارعة، تسعى كل شركة للنمو. ولكن الأرقام تشير إلى واقع مؤلم: الغالبية العظمى من استراتيجيات النمو تفشل في تحقيق أهدافها. لماذا؟</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">1. الفجوة بين الاستراتيجية والتنفيذ</h3>
            <p>كثيراً ما نرى خططاً استراتيجية رائعة على الورق، ولكنها تفتقر إلى آلية تنفيذ واضحة. الاستراتيجية التي لا تتحول إلى مهام يومية قابلة للقياس هي مجرد أمنيات.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">2. الاعتماد على "الحلول السحرية"</h3>
            <p>النمو المستدام هو عملية تراكمية، وليس نتيجة لـ "هجمة" تسويقية واحدة أو أداة تقنية جديدة. الشركات التي تبحث عن الحل السريع غالباً ما تصطدم بالحائط.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">3. غياب البيانات الدقيقة</h3>
            <p>لا يمكنك تحسين ما لا يمكنك قياسه. القرارات المبنية على الحدس بدلاً من البيانات تؤدي إلى هدر الميزانيات في قنوات غير مجدية.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">الحل: بناء "محرك نمو"</h3>
            <p>بدلاً من الحملات المتفرقة، يجب بناء نظام متكامل (Ecosystem) يربط جذب العملاء بآليات البيع والاحتفاظ بهم، مدعوماً ببنية بيانات قوية توضح الرؤية لحظة بلحظة.</p>
        `,
        contentEn: `
            <p>In a rapidly changing world, every company seeks growth. Yet, the numbers paint a stark reality: the vast majority of growth strategies fail to hit their targets. Why?</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">1. The Strategy-Execution Gap</h3>
            <p>We often see brilliant strategic plans on paper that lack a clear execution mechanism. A strategy that doesn't translate into measurable daily tasks is just a wish.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">2. Reliance on "Magic Bullets"</h3>
            <p>Sustainable growth is a cumulative process, not the result of a single marketing blitz or a new tech tool. Companies looking for quick fixes often hit a wall.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">3. Lack of Accurate Data</h3>
            <p>You can't optimize what you can't measure. Decisions based on intuition rather than data lead to wasted budgets on ineffective channels.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">The Solution: Building a "Growth Engine"</h3>
            <p>Instead of sporadic campaigns, you must build an integrated ecosystem connecting acquisition, sales, and retention, supported by a robust data infrastructure that provides real-time visibility.</p>
        `
    },
    {
        id: 2,
        date: '2025-12-28',
        titleAr: 'أهمية ربط التسويق بالمبيعات تقنياً',
        titleEn: 'The Importance of Tech-aligned Marketing',
        excerptAr: 'كيف يمكن لأتمتة تدفق البيانات بين فرق التسويق والمبيعات أن يضاعف معدلات الإغلاق.',
        excerptEn: 'How automating data flow between marketing and sales can double close rates.',
        contentAr: `
            <p>الصراع الأزلي: فريق التسويق يقول "جلبنا لكم عملاء محتملين (Leads) لكنكم لم تغلقوا الصفقات"، وفريق المبيعات يرد "العملاء الذين جلبتموهم غير مهتمين أصلاً".</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">مكمن الخلل</h3>
            <p>المشكلة ليست في الأشخاص، بل في النظام. عندما تكون البيانات مفصولة، يفقد الطرفان السياق. المسوق لا يعرف أي القنوات جلبت أفضل الزبائن، والبائع لا يعرف تاريخ العميل قبل الاتصال.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">قوة الربط التقني (Integration)</h3>
            <p>تخيل سيناريو مختلفاً: يسجل العميل اهتمامه، فينتقل تلقائياً إلى نظام CRM. وبناءً على سلوكه (مثلاً: زار صفحة الأسعار)، يتم تصنيفه كـ "عميل حار"، ويتم إشعار أفضل بائع لديكم فوراً.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">النتيجة</h3>
            <p>تشير الدراسات إلى أن الشركات التي تمتلك توافقاً عالياً بين التسويق والمبيعات تحقق نمواً في الإيرادات أسرع بـ 3 مرات. التقنية هي الجسر الذي يجعل هذا التوافق ممكناً وتلقائياً.</p>
        `,
        contentEn: `
            <p>The eternal conflict: Marketing says "We brought you leads, but you didn't close them," and Sales replies "The leads you brought aren't qualified."</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">The Root Cause</h3>
            <p>The problem isn't the people, it's the system. When data is siloed, both sides lose context. Marketers don't know which channels brought the best customers, and sales reps don't know the lead's history before calling.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">The Power of Technical Integration</h3>
            <p>Imagine a different scenario: A lead registers and is automatically pushed to the CRM. Based on their behavior (e.g., visited the pricing page), they are scored as "Hot" and your best sales rep is notified instantly.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">The Outcome</h3>
            <p>Studies show that companies with strong marketing-sales alignment achieve revenue growth 3 times faster. Technology is the bridge that makes this alignment possible and automatic.</p>
        `
    },
    {
        id: 3,
        date: '2025-12-15',
        titleAr: 'التحول من الإدارة بالحدس إلى الإدارة بالبيانات',
        titleEn: 'Shifting from Intuition to Data-Driven',
        excerptAr: 'خطوات عملية لبناء ثقافة تعتمد على الأرقام والحقائق في اتخاذ القرارات اليومية.',
        excerptEn: 'Practical steps to build a culture relying on numbers and facts for daily decisions.',
        contentAr: `
            <p>"أعتقد أننا يجب أن نفعل كذا..." - هذه الجملة هي العدو الأول للنمو. في عصر البيانات، لم يعد هناك مجال للتخمين.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">بناء البنية التحتية للبيانات</h3>
            <p>الخطوة الأولى هي التأكد من أنك تجمع البيانات الصحيحة. هل تتبع مصادر الزيارات بدقة؟ هل تعرف تكلفة الاستحواذ على العميل (CAC) لكل قناة؟ القيمة الدائمة للعميل (LTV)؟</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">تحويل البيانات إلى رؤى (Insights)</h3>
            <p>البيانات الخام لا تفيد. تحتاج إلى لوحات مؤشرات (Dashboards) تحول هذه الأرقام إلى قصص بصرية تساعد المدير التنفيذي ومدير التسويق على فهم الوضع في ثوانٍ.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">ثقافة المساءلة</h3>
            <p>عندما تكون الأرقام واضحة ومتاحة للجميع، تتغير لغة الاجتماعات. بدلاً من الجدال حول الآراء، يصبح النقاش حول كيفية تحسين المؤشرات. هذه هي الثقافة التي تصنع الشركات المليارية.</p>
        `,
        contentEn: `
            <p>"I think we should do this..." - This phrase is the number one enemy of growth. In the age of data, there is no room for guessing.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">Building Data Infrastructure</h3>
            <p>The first step is ensuring you collect the right data. Are you tracking traffic sources accurately? Do you know the Customer Acquisition Cost (CAC) per channel? The Lifetime Value (LTV)?</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">Turning Data into Insights</h3>
            <p>Raw data is useless. You need dashboards that turn these numbers into visual stories, helping the CEO and CMO understand the situation in seconds.</p>
            <h3 style="color:var(--accent-primary); margin-top:20px;">Culture of Accountability</h3>
            <p>When numbers are clear and accessible to everyone, the language of meetings changes. Instead of arguing over opinions, the discussion shifts to optimizing metrics. This is the culture that builds unicorn companies.</p>
        `
    }
];

const servicesData = [
    {
        key: 'growth',
        titleAr: 'استراتيجية النمو والتسويق', titleEn: 'Growth & Marketing Strategy',
        descAr: 'خطة 90 يوم، إطار عمل KPIs، تقسيم السوق.', descEn: '90-day plan, KPI framework, go-to-market.',
        details: {
            ar: {
                scope: ['ورش عمل لفهم عميق لنموذج العمل', 'تحليل المنافسين والفجوات السوقية', 'بناء نماذج شخصيات العملاء (Personas)', 'وضع خطة تنفيذية مفصلة (90 يوم)', 'تحديد ميزانيات التسويق وتوقعات النمو'],
                features: ['خطة عمل مفصلة لمدة 90 يوم', 'بناء إطار قياس الأداء (KPIs)', 'تحليل المنافسين وتقسيم السوق'],
                process: ['تحليل الوضع الحالي والفجوات', 'تصميم الاستراتيجية وتحديد الأولويات', 'تسليم خطة التنفيذ والجدول الزمني'],
                benefits: ['رؤية واضحة للفريق بأكمله', 'تركيز الموارد على القنوات الأنجح', 'أهداف قابلة للقياس والتحقيق']
            },
            en: {
                scope: ['Deep-dive workshops on business model', 'Competitor analysis & gap identification', 'Customer Persona development', 'Detailed 90-day execution roadmap', 'Marketing budget allocation & growth forecasting'],
                features: ['Detailed 90-Day Execution Plan', 'KPI Measurement Framework', 'Competitor Analysis & Segmentation'],
                process: ['Current State & Gap Analysis', 'Strategy Design & Prioritization', 'Execution Roadmap Delivery'],
                benefits: ['Clear Vision for the Whole Team', 'Focus Resources on Moving the Needle', 'Measurable & Achievable Goals']
            }
        }
    },
    {
        key: 'funnels',
        titleAr: 'مسارات التحويل وصفحات الهبوط', titleEn: 'Conversion Funnels',
        descAr: 'صفحات عالية التحويل، تحسين تجربة المستخدم.', descEn: 'High-conversion pages, UX, CRO.',
        details: {
            ar: {
                scope: ['رسم رحلة المستخدم (User Journey)', 'كتابة النصوص البيعية (Copywriting)', 'تصميم واجهة الاستخدام (UI/UX)', 'التطوير البرمجي للصفحات', 'إعداد اختبارات A/B'],
                features: ['تدقيق معدل التحويل (CRO Audit)', 'تصميم صفحات هبوط بيعية', 'اختبارات A/B مستمرة'],
                process: ['بحث وتحليل سلوك المستخدم', 'تصميم الهيكل والمحتوى', 'التطوير والاختبار التقني'],
                benefits: ['خفض تكلفة الاستحواذ (CAC)', 'زيادة العائد من الزوار الحاليين', 'تحسين تجربة العميل']
            },
            en: {
                scope: ['User Journey Mapping', 'Sales Copywriting', 'UI/UX Design', 'Page Development & Coding', 'A/B Testing Setup'],
                features: ['CRO Audit & Optimization', 'Sales Landing Page Design', 'Continuous A/B Testing'],
                process: ['User Behavior Research', 'Wireframing & Copywriting', 'Development & Tech Testing'],
                benefits: ['Lower Customer Acquisition Cost (CAC)', 'Higher Revenue from Existing Traffic', 'Enhanced User Experience']
            }
        }
    },
    {
        key: 'crm',
        titleAr: 'أنظمة إدارة العملاء (CRM)', titleEn: 'CRM System Design',
        descAr: 'pipelines، تسجيل النقاط (Scoring)، التوجيه الآلي.', descEn: 'Pipelines, lead scoring, automatic routing.',
        details: {
            ar: {
                scope: ['تقييم دورة المبيعات الحالية', 'تصميم وهيكلة الـ Pipeline', 'أتمتة توزيع العملاء (Routing)', 'إعداد نظام النقاط (Scoring)', 'تدريب فريق المبيعات'],
                features: ['هيكلة مراحل المبيعات (Pipelines)', 'نظام تنقيط العملاء (Lead Scoring)', 'لوحات متابعة الأداء للفريق'],
                process: ['رسم رحلة العميل وتدفق البيانات', 'تخصيص النظام (HubSpot/Pipedrive)', 'تدريب الفريق وأتمتة المهام'],
                benefits: ['عدم ضياع أي فرصة بيعية', 'توقعات مبيعات دقيقة', 'متابعة آلية ومنظمة']
            },
            en: {
                scope: ['Sales Cycle Assessment', 'Pipeline Architecture & Design', 'Automated Lead Routing', 'Lead Scoring Logic Setup', 'Sales Team Training'],
                features: ['Sales Pipeline Architecture', 'Lead Scoring Logic', 'Team Performance Dashboards'],
                process: ['Journey Mapping & Data Flow', 'System Customization', 'Team Training & Automation'],
                benefits: ['Zero Lost Leads', 'Accurate Sales Forecasting', 'Organized & Automated Follow-up']
            }
        }
    },
    {
        key: 'ads',
        titleAr: 'تحسين تسويق الأداء', titleEn: 'Performance Marketing',
        descAr: 'منطق الميزانية، عقلية العائد على الإنفاق (ROAS).', descEn: 'Budget logic, ROAS mindset, experiments.',
        details: {
            ar: {
                scope: ['إعداد الحسابات الإعلانية والبيكسل', 'تجزئة الجمهور المستهدف', 'إدارة الحملات اليومية', 'تحليل النتائج الأسبوعي', 'اختبار الإعلانات الجديدة (Testing)'],
                features: ['إدارة حملات متعددة القنوات', 'اختبارات إبداعية (Creatives)', 'تحسين الميزانية والعائد'],
                process: ['تحليل الجمهور والاستهداف', 'إطلاق الحملات التجريبية', 'التحسين الأسبوعي المستمر'],
                benefits: ['نمو قابل للتوسع في الإيرادات', 'تحكم كامل في تكلفة الإعلان', 'تقارير شفافة ودقيقة']
            },
            en: {
                scope: ['Ad Account & Pixel Setup', 'Audience Segmentation', 'Daily Campaign Management', 'Weekly Performance Analysis', 'Creative Testing Cycles'],
                features: ['Multi-channel Campaign Management', 'Creative Testing Framework', 'Budget & ROAS Optimization'],
                process: ['Audience Analysis & Targeting', 'Launch Pilot Campaigns', 'Continuous Weekly Optimization'],
                benefits: ['Scalable Revenue Growth', 'Controlled Ad Spend', 'Transparent Reporting']
            }
        }
    },
    {
        key: 'data',
        titleAr: 'تحليل البيانات والتقارير', titleEn: 'Data Analytics & Dashboards',
        descAr: 'لوحات تنفيذية، دورية التقارير، رؤى معمقة.', descEn: 'Executive dashboards, reporting cadence.',
        details: {
            ar: {
                scope: ['تدقيق صحة البيانات (Data Audit)', 'بناء مستودع البيانات (Data Warehouse)', 'تصميم لوحات المعلومات (Looker Studio)', 'ربط المصادر المختلفة', 'أتمتة التقارير الدورية'],
                features: ['لوحات بيانات تفاعلية (Looker)', 'تتبع دقيق للأحداث (Tracking)', 'دمج مصادر البيانات المختلفة'],
                process: ['مراجعة البنية التحتية للبيانات', 'بناء المستودع (Data Warehouse)', 'تصميم الواجهات المرئية'],
                benefits: ['قرارات مبنية على حقائق', 'رؤية شاملة للأداء في مكان واحد', 'كشف فرص النمو الخفية']
            },
            en: {
                scope: ['Data Integrity Audit', 'Data Warehouse Setup (BigQuery/SQL)', 'Dashboard Design (Looker Studio)', 'Source Integration (ETL)', 'Automated Reporting'],
                features: ['Interactive Dashboards (Looker)', 'Precise Event Tracking', 'Data Source Integration'],
                process: ['Data Infrastructure Audit', 'Data Warehousing Setup', 'Visualization Design'],
                benefits: ['Fact-Based Decision Making', 'Unified Performance View', 'Uncovering Hidden Opportunities']
            }
        }
    },
    {
        key: 'auto',
        titleAr: 'أتمتة العمليات', titleEn: 'Workflow Automation',
        descAr: 'تقليل العمل اليدوي، تحسين السرعة والحوكمة.', descEn: 'Reduce manual work, improve speed & governance.',
        details: {
            ar: {
                scope: ['رسم التدفقات التشغيلية (Flowcharts)', 'برمجة سيناريوهات الأتمتة (Make/Zapier)', 'اختبار حالات الفشل (Error Handling)', 'توثيق العمليات المؤتمتة'],
                features: ['ربط التطبيقات (Integrations)', 'معالجة الأخطاء وإشعاراتها', 'سيناريوهات معقدة ومتشعبة'],
                process: ['تحديد الاختناقات والعمل اليدوي', 'تصميم منطق الأتمتة', 'البناء والاختبار والإطلاق'],
                benefits: ['توفير مئات الساعات شهرياً', 'القضاء على الأخطاء البشرية', 'سرعة استجابة فورية']
            },
            en: {
                scope: ['Operational Workflow Mapping', 'Automation Scenario Building (Make/Zapier)', 'Error Handling Setup', 'Process Documentation'],
                features: ['App Integrations', 'Error Handling & Notifications', 'Complex Logic Scenarios'],
                process: ['Identify Bottlenecks', 'Design Automation Logic', 'Build, Test, Launch'],
                benefits: ['Save Hundreds of Hours Monthly', 'Eliminate Human Error', 'Instant Operational Speed']
            }
        }
    }
];

let curLang = 'ar';

/* --- LOGIC --- */
function init() {
    renderServices();
    updateLang('ar');
    init3D();
}

function router(page) {
    document.querySelectorAll('.page-section').forEach(el => el.classList.remove('active'));
    // Close modal if open when navigating
    closeModal();
    document.getElementById(page) ? document.getElementById(page).classList.add('active') : document.getElementById('home').classList.add('active');
    window.scrollTo(0, 0);
}

function renderServices() {
    const markup = servicesData.map(s => `
        <div class="glass-panel service-card" onclick="openDetail('${s.key}')">
            <div class="icon-box"><i class="fas fa-arrow-${curLang === 'ar' ? 'left' : 'right'}"></i></div>
            <h3 data-key="${s.key}" class="s-title" style="font-size:1.5rem; margin-bottom:10px;">${curLang === 'ar' ? s.titleAr : s.titleEn}</h3>
            <p data-key="${s.key}" class="s-desc" style="color:var(--text-secondary); margin-bottom:auto;">${curLang === 'ar' ? s.descAr : s.descEn}</p>
            <div style="margin-top:20px; color:var(--accent-primary); font-size:0.9rem; font-weight:bold;">
                ${curLang === 'ar' ? 'عرض التفاصيل' : 'View Details'} &rarr;
            </div>
        </div>
    `).join('');
    const grid1 = document.getElementById('services-grid');
    const grid2 = document.getElementById('home-services');
    if (grid1) grid1.innerHTML = markup;
    if (grid2) grid2.innerHTML = markup;
}

function openDetail(key) {
    const s = servicesData.find(x => x.key === key);
    if (!s) return;

    const content = s.details[curLang]; // Get 'ar' or 'en' details
    const labels = curLang === 'ar'
        ? { features: 'المميزات', process: 'منهجية العمل', benefits: 'النتائج المتوقعة', book: 'احجز استشارة لهذه الخدمة', scope: 'ماذا نقدم في هذه الخدمة؟ (نطاق العمل)' }
        : { features: 'Key Features', process: 'Our Process', benefits: 'Expected Outcomes', book: 'Book Consultation', scope: 'What We Do (Scope of Work)' };

    const html = `
        <div style="max-width:900px; margin:0 auto; padding-top:40px;">
            <h1 class="gradient-text" style="font-size:3rem; margin-bottom:10px; text-align:center;">${curLang === 'ar' ? s.titleAr : s.titleEn}</h1>
            <p style="text-align:center; color:var(--text-secondary); margin-bottom:50px; font-size:1.2rem;">${curLang === 'ar' ? s.descAr : s.descEn}</p>
            
            <!-- NEW: Scope of Work Section -->
            <div class="glass-panel" style="padding:30px; margin-bottom:30px; border-left: 4px solid var(--accent-primary);">
                <h3 style="color:var(--accent-primary); margin-bottom:20px;">${labels.scope}</h3>
                <ul class="list-check" style="list-style:none;">
                    ${content.scope ? content.scope.map(i => `<li style="margin-bottom:10px; display:flex; gap:10px;"><i class="fas fa-dot-circle" style="color:var(--accent-glow);"></i> ${i}</li>`).join('') : ''}
                </ul>
            </div>

            <div class="grid-2">
                <div class="glass-panel" style="padding:30px;">
                    <h3 style="color:var(--accent-primary); margin-bottom:20px;">${labels.features}</h3>
                    <ul class="list-check" style="list-style:none;">
                        ${content.features.map(f => `<li style="margin-bottom:10px; display:flex; gap:10px;"><i class="fas fa-check-circle" style="color:var(--accent-glow);"></i> ${f}</li>`).join('')}
                    </ul>
                </div>
                 <div class="glass-panel" style="padding:30px;">
                    <h3 style="color:var(--accent-primary); margin-bottom:20px;">${labels.benefits}</h3>
                    <ul class="list-check" style="list-style:none;">
                        ${content.benefits.map(f => `<li style="margin-bottom:10px; display:flex; gap:10px;"><i class="fas fa-star" style="color:var(--accent-glow);"></i> ${f}</li>`).join('')}
                    </ul>
                </div>
            </div>

            <div class="glass-panel" style="padding:30px; margin-top:30px;">
                 <h3 style="color:var(--accent-primary); margin-bottom:20px;">${labels.process}</h3>
                 <div style="display:flex; flex-wrap:wrap; gap:20px; text-align:center;">
                     ${content.process.map((step, i) => `
                        <div style="flex:1; min-width:200px; background:rgba(255,255,255,0.03); padding:20px; border-radius:10px;">
                            <div style="font-size:2rem; font-weight:900; opacity:0.3; margin-bottom:10px;">0${i + 1}</div>
                            <div>${step}</div>
                        </div>
                     `).join('')}
                 </div>
            </div>

            <div style="text-align:center; margin-top:50px; margin-bottom:50px;">
                <button class="btn btn-primary" onclick="closeModal(); router('request-meeting');" style="font-size:1.2rem; padding:15px 40px;">
                    ${labels.book}
                </button>
            </div>
        </div>
    `;

    document.getElementById('modal-content').innerHTML = html;
    document.getElementById('service-modal').classList.add('active');
}

function closeModal() {
    document.getElementById('service-modal').classList.remove('active');
}

/* Render Blog */
function renderBlog() {
    const blogContainer = document.querySelector('#blog .container');
    if (!blogContainer) return;

    // Check if we just have the placeholder
    if (blogContainer.innerHTML.includes('قريباً') || blogContainer.children.length < 2) {
        const title = curLang === 'ar' ? 'المدونة رؤى' : 'Insights & Blog';
        blogContainer.innerHTML = `
            <h1 class="gradient-text gradient-title" style="margin-bottom:50px;" data-i18n="nav.blog">${title}</h1>
            <div class="grid-3" id="blog-grid"></div>
         `;
    }

    const markup = blogData.map(post => `
        <div class="glass-panel" style="padding:25px; text-align:start; display:flex; flex-direction:column;">
            <div style="font-size:0.8rem; color:var(--accent-primary); margin-bottom:10px;">${post.date}</div>
            <h3 style="margin-bottom:15px; font-size:1.3rem;">${curLang === 'ar' ? post.titleAr : post.titleEn}</h3>
            <p style="color:var(--text-secondary); font-size:0.95rem; line-height:1.6; flex-grow:1;">${curLang === 'ar' ? post.excerptAr : post.excerptEn}</p>
            <button class="btn btn-outline" style="margin-top:20px; font-size:0.8rem; padding:8px 20px;" onclick="openBlogDetail(${post.id})">
                ${curLang === 'ar' ? 'اقرأ المزيد' : 'Read More'}
            </button>
        </div>
     `).join('');

    const grid = document.getElementById('blog-grid');
    if (grid) grid.innerHTML = markup;
}

function openBlogDetail(id) {
    const post = blogData.find(p => p.id === id);
    if (!post) return;

    const html = `
        <div style="max-width:800px; margin:0 auto; padding-top:40px;">
            <div style="font-size:0.9rem; color:var(--accent-primary); margin-bottom:10px; text-align:center;">${post.date}</div>
            <h1 class="gradient-text" style="font-size:2.5rem; margin-bottom:30px; text-align:center;">${curLang === 'ar' ? post.titleAr : post.titleEn}</h1>
            <div class="glass-panel" style="padding:40px; line-height:1.8; font-size:1.1rem; color:var(--text-primary);">
                ${curLang === 'ar' ? post.contentAr : post.contentEn}
                <br><br>

            </div>
             <div style="text-align:center; margin-top:50px; margin-bottom:50px;">
                <button class="btn btn-primary" onclick="closeModal()" style="font-size:1.2rem; padding:15px 40px;">${curLang === 'ar' ? 'إغلاق' : 'Close'}</button>
            </div>
        </div>
    `;
    document.getElementById('modal-content').innerHTML = html;
    document.getElementById('service-modal').classList.add('active');
}

function updateLang(lang) {
    curLang = lang;
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.getElementById('lang-btn').textContent = lang === 'ar' ? 'En' : 'عربي';

    // Static
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const k = el.dataset.i18n;
        if (translations[lang][k]) el.textContent = translations[lang][k];
    });

    // Placeholders
    document.querySelectorAll('[data-ph]').forEach(el => {
        const k = el.dataset.ph;
        if (translations[lang][k]) el.placeholder = translations[lang][k];
    });

    // Dynamic Services
    document.querySelectorAll('.s-title').forEach(el => {
        const s = servicesData.find(x => x.key === el.dataset.key);
        el.innerText = lang === 'ar' ? s.titleAr : s.titleEn;
    });
    document.querySelectorAll('.s-desc').forEach(el => {
        const s = servicesData.find(x => x.key === el.dataset.key);
        el.innerText = lang === 'ar' ? s.descAr : s.descEn;
    });

    renderBlog();

    // Render Why Lists
    const renderWhyList = (id, data) => {
        const list = document.getElementById(id);
        if (list && data && data[lang]) {
            list.innerHTML = data[lang].map(i => `<li style="margin-bottom:15px; display:flex; gap:10px; align-items:start;"><i class="fas fa-check-circle" style="color:var(--accent-primary); margin-top:5px;"></i> <span>${i}</span></li>`).join('');
        }
    };
    if (typeof whyData !== 'undefined') {
        renderWhyList('why-accreditations', whyData.accreditations);
        renderWhyList('why-capabilities', whyData.capabilities);
        renderWhyList('why-operational', whyData.operational);
        renderWhyList('why-unique', whyData.unique);
    }
}

function toggleLanguage() { updateLang(curLang === 'ar' ? 'en' : 'ar'); }
function toggleTheme() { document.body.classList.toggle('light-mode'); }

/* --- FORMS & SCORING --- */
function calculateScore(data) {
    let score = 0;
    // Size
    if (data.size === '51-200') score += 15;
    if (data.size === '201-500') score += 20;
    if (data.size === '500+') score += 25;
    // Budget
    if (data.budget === 'Mid' || data.budget === 'High') score += 20;
    // Timeline
    if (data.timeline === 'ASAP') score += 15;
    // Services
    if (data.services && data.services.length >= 3) score += 10;

    return score;
}

// FORM HANDLING
function handleMeetingSubmit(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button');
    const originalText = btn.innerText;
    btn.innerText = curLang === 'ar' ? 'جاري الإرسال...' : 'Sending...';
    btn.disabled = true;

    const formData = new FormData(e.target);

    // Netlify Submission
    fetch('/', {
        method: 'POST',
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams(formData).toString()
    })
        .then(() => {
            setTimeout(() => {
                btn.innerText = originalText;
                btn.disabled = false;
                router('thank-you');
                e.target.reset();
            }, 1000);
        })
        .catch((error) => {
            alert(error);
            btn.innerText = originalText;
            btn.disabled = false;
        });
}

function handleProposalSubmit(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button');
    const originalText = btn.innerText;
    btn.innerText = curLang === 'ar' ? 'جاري الإرسال...' : 'Sending...';
    btn.disabled = true;

    const formData = new FormData(e.target);

    // Netlify Submission
    fetch('/', {
        method: 'POST',
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams(formData).toString()
    })
        .then(() => {
            setTimeout(() => {
                btn.innerText = originalText;
                btn.disabled = false;
                router('thank-you');
                e.target.reset();
            }, 1000);
        })
        .catch((error) => {
            alert(error);
            btn.innerText = originalText;
            btn.disabled = false;
        });
}

function handleContactSubmit(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button');
    const originalText = btn.innerText;
    btn.innerText = curLang === 'ar' ? 'جاري الإرسال...' : 'Sending...';
    btn.disabled = true;

    const formData = new FormData(e.target);

    // Netlify Submission
    fetch('/', {
        method: 'POST',
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams(formData).toString()
    })
        .then(() => {
            setTimeout(() => {
                alert(curLang === 'ar' ? 'شكراً لتواصلك معنا' : 'Thank you for contacting us');
                btn.innerText = originalText;
                btn.disabled = false;
                e.target.reset();
            }, 1000);
        })
        .catch((error) => {
            alert(error);
            btn.innerText = originalText;
            btn.disabled = false;
        });
}
/* --- 3D ANIMATION (REUSABLE MODULE) --- */
function init3D() {
    const container = document.getElementById('canvas-container');
    // Clear if exists
    while (container.firstChild) container.removeChild(container.firstChild);

    // CONFIG
    const CONFIG = {
        coreSize: 6,
        coreDetail: 1,
        particleCount: 900,
        mouseSensitivity: 0.001, // Increased sensitivity
        rotationSpeed: 0.001
    };

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 30;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // MATERIALS
    const coreMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.3 });
    const outerMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.2 });
    const particleMaterial = new THREE.PointsMaterial({ color: 0xffffff, size: 0.1, transparent: true, opacity: 0.8 });

    // OBJECTS
    // 1. Core
    const coreGeo = new THREE.IcosahedronGeometry(CONFIG.coreSize, CONFIG.coreDetail);
    const coreMesh = new THREE.Mesh(coreGeo, coreMaterial);
    scene.add(coreMesh);

    // 2. Outer (Torus Knot)
    const outerGeo = new THREE.TorusKnotGeometry(12, 3, 100, 16);
    const outerMesh = new THREE.Mesh(outerGeo, outerMaterial);
    scene.add(outerMesh);

    // 3. Particles
    const particlesGeo = new THREE.BufferGeometry();
    const posArray = new Float32Array(CONFIG.particleCount * 3);
    for (let i = 0; i < CONFIG.particleCount * 3; i++) {
        posArray[i] = (Math.random() - 0.5) * 60;
    }
    particlesGeo.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    const particlesMesh = new THREE.Points(particlesGeo, particleMaterial);
    scene.add(particlesMesh);

    // COLOR SYNC
    function getCSSVariable(name, fallbackStr) {
        const val = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
        return val || fallbackStr;
    }
    function updateThemeColors() {
        const primary = getCSSVariable('--accent-primary', '#3b82f6');
        const glow = getCSSVariable('--accent-glow', '#8b5cf6');
        coreMaterial.color.set(primary);
        outerMaterial.color.set(glow);
        particleMaterial.color.set(primary);
    }
    updateThemeColors(); // Initial

    // Observers
    const observer = new MutationObserver(updateThemeColors);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });

    // MOUSE & RESIZE
    let mouseX = 0, mouseY = 0;
    let targetX = 0, targetY = 0;
    const windowHalfX = window.innerWidth / 2;
    const windowHalfY = window.innerHeight / 2;

    document.addEventListener('mousemove', (event) => {
        mouseX = (event.clientX - windowHalfX);
        mouseY = (event.clientY - windowHalfY);
    });

    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // ANIMATION
    const clock = new THREE.Clock();
    function animate() {
        requestAnimationFrame(animate);

        // Mouse Smoothing
        targetX = mouseX * CONFIG.mouseSensitivity;
        targetY = mouseY * CONFIG.mouseSensitivity;

        // Core
        coreMesh.rotation.y += CONFIG.rotationSpeed;
        coreMesh.rotation.x += 0.05 * (targetY - coreMesh.rotation.x);
        coreMesh.rotation.y += 0.05 * (targetX - coreMesh.rotation.y);

        // Outer
        outerMesh.rotation.y -= CONFIG.rotationSpeed * 0.5;
        outerMesh.rotation.z += 0.001;
        outerMesh.rotation.x += 0.02 * (targetY - outerMesh.rotation.x);
        outerMesh.rotation.y += 0.02 * (targetX - outerMesh.rotation.y);

        // Particles
        particlesMesh.rotation.y = mouseX * 0.0001;
        particlesMesh.rotation.x = mouseY * 0.0001;

        renderer.render(scene, camera);
    }
    animate();
}

// Add Legal & Cases Functionality
function renderCases() {
    const container = document.getElementById('cases-grid');
    if (!container) return;
    container.innerHTML = casesData.map(c => `
        <div class="glass-panel" style="padding:30px;">
            <div class="icon-box"><i class="fas fa-chart-line"></i></div>
            <h3 style="margin-bottom:15px;" class="gradient-text">${curLang === 'ar' ? c.titleAr : c.titleEn}</h3>
            <p style="color:var(--text-secondary); margin-bottom:20px;">${curLang === 'ar' ? c.descAr : c.descEn}</p>
            <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:20px;">
                ${c.metrics.map(m => `<span style="background:rgba(59,130,246,0.1); color:var(--accent-primary); padding:5px 10px; borderRadius:5px; font-size:0.8rem;">${m}</span>`).join('')}
            </div>
        </div>
    `).join('');
}

function openLegal(type) {
    const titles = {
        privacy: curLang === 'ar' ? 'سياسة الخصوصية' : 'Privacy Policy',
        terms: curLang === 'ar' ? 'شروط الاستخدام' : 'Terms of Use'
    };
    const content = curLang === 'ar'
        ? 'هذه الصفحة تحتوي على نص تجريبي لسياسة الخصوصية/الشروط. سيتم إضافة النص القانوني الكامل لاحقاً.'
        : 'This page contains placeholder text for Privacy Policy/Terms. Full legal text will be added later.';

    const html = `
        <div style="max-width:800px; margin:0 auto; padding-top:40px;">
            <h1 class="gradient-text" style="text-align:center; margin-bottom:30px;">${titles[type]}</h1>
            <div class="glass-panel" style="padding:40px; color:var(--text-secondary); line-height:1.8;">
                <p>${content}</p>
            </div>
            <div style="text-align:center; margin-top:30px;">
                <button class="btn btn-primary" onclick="closeModal()">Close</button>
            </div>
        </div>
    `;
    document.getElementById('modal-content').innerHTML = html;
    document.getElementById('service-modal').classList.add('active');
}

// Hook renderCases into updateLang
// Note: We need to avoid infinite recursion if we were using the old patterns, but here we can just modify updateLang directly above or keep the hooking pattern if cleaner.
// I'll update the updateLang function above to call renderCases() directly, it's cleaner than hooking.

/* Init All */
window.addEventListener('DOMContentLoaded', () => {
    renderServices(); // Generate service cards
    // Check for router hash or default
    router(curLang === 'ar' ? 'home' : 'home'); // Default
    updateLang(curLang);
    init3D();
    renderCases(); // Ensure cases are rendered on load
});

