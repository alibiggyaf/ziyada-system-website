import { useOutletContext } from "react-router-dom";
import ServiceDetailPage from "../components/ziyada/ServiceDetailPage.jsx";
import ROICalculator from "../components/ziyada/ROICalculator.jsx";
import { IconZap } from "../components/ziyada/BrandIcons.jsx";

const DATA = {
  ar: {
    icon: IconZap,
    tag: "الأكثر طلباً",
    title: "أتمتة سير العمل بـ n8n + الذكاء الاصطناعي",
    desc: "نبني لك أنظمة أتمتة كاملة تربط أدواتك وتُشغّل عملياتك 24/7 دون تدخل بشري.",
    scope: ["تحليل المهام اليدوية المتكررة", "تصميم وبناء workflows كاملة", "ربط 300+ تطبيق (CRM، Email، WhatsApp)", "أتمتة توليد العملاء والمتابعة", "تقارير يومية تلقائية", "دمج نماذج الذكاء (GPT، Claude)", "توثيق وتدريب الفريق"],
    features: ["workflows مخصصة 100%", "تكامل مع 300+ تطبيق", "أتمتة التسويق والمبيعات والعمليات", "دمج نماذج الذكاء الاصطناعي", "مراقبة فورية وتنبيهات لحظية", "لوحة تحكم مركزية"],
    results: ["توفير 40–80 ساعة شهرياً", "صفر أخطاء بشرية", "استجابة فورية للعمليات", "تكبير بدون توظيف إضافي"],
    case: { who: "شركة استشارات عقارية في الرياض تستقبل 200+ استفسار شهرياً", what: "نظام أتمتة يستقبل الاستفسارات من واتساب وإيميل، يصنّفها، يُرسل رد تلقائي، ويُسجّلها في CRM", when: "خلال 3 أسابيع", where: "واتساب + Gmail + HubSpot CRM + Google Sheets", why: "كان الفريق يضيع 3 ساعات يومياً في الردود اليدوية — الآن يتم بشكل تلقائي 100%" }
  },
  en: {
    icon: IconZap,
    tag: "Most Requested",
    title: "n8n + AI Workflow Automation",
    desc: "We build complete automation systems that connect your tools and run your operations 24/7 without human intervention.",
    scope: ["Analyze repetitive manual tasks", "Design and build complete workflows", "Connect 300+ apps (CRM, Email, WhatsApp)", "Automate lead gen and follow-ups", "Automated daily reports", "Integrate AI models (GPT, Claude)", "Documentation and team training"],
    features: ["100% custom workflows", "Integration with 300+ apps", "Marketing, sales & ops automation", "AI model integration", "Real-time monitoring and alerts", "Central control dashboard"],
    results: ["Save 40–80 hours/month", "Zero human errors", "Instant response to operations", "Scale without extra hiring"],
    case: { who: "A real estate consulting firm in Riyadh receiving 200+ inquiries/month", what: "Automation system that receives inquiries from WhatsApp and email, classifies them, sends auto-replies, and logs them in CRM", when: "Within 3 weeks", where: "WhatsApp + Gmail + HubSpot CRM + Google Sheets", why: "The team was wasting 3 hours/day on manual replies — now 100% automated" }
  }
};

export default function ServiceAutomation() {
  const { lang } = useOutletContext();
  return (
    <>
      <ServiceDetailPage data={DATA[lang] || DATA.ar} lang={lang} />
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
        <ROICalculator lang={lang} />
      </div>
    </>
  );
}