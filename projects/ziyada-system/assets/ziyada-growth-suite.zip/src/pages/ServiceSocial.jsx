import { useOutletContext } from "react-router-dom";
import ServiceDetailPage from "../components/ziyada/ServiceDetailPage.jsx";
import ROICalculator from "../components/ziyada/ROICalculator.jsx";
import { IconShare } from "../components/ziyada/BrandIcons.jsx";

const DATA = {
  ar: {
    icon: IconShare,
    tag: "حضور مميز",
    title: "إدارة منصات التواصل الاجتماعي",
    desc: "نُدير حضورك الرقمي بمحتوى استراتيجي يبني مجتمعاً من العملاء المحتملين ويعزّز ثقتهم بعلامتك.",
    scope: ["استراتيجية محتوى مخصصة", "إنشاء محتوى نصي ومرئي", "تصميم جرافيك احترافي", "جدول نشر منظّم", "إدارة التعليقات والرسائل", "تقارير أداء شهرية"],
    features: ["محتوى موجّه لجمهورك المثالي", "تصميم يعكس هويتك البصرية", "نشر منتظم على كل المنصات", "رد سريع على الجمهور", "تقارير نمو واضحة"],
    results: ["بناء حضور قوي ومستمر", "زيادة الوعي بالعلامة التجارية", "جمهور يتحوّل لعملاء", "مصداقية ومهنية في السوق"],
    case: { who: "مكتب عقاري ناشئ يريد بناء حضور رقمي قوي في جدة", what: "إدارة Instagram + LinkedIn مع 20 منشور شهري، تصاميم احترافية، واستراتيجية محتوى تعليمي", when: "بدأنا من الصفر ووصلنا إلى 5,000 متابع في 4 أشهر", where: "Instagram + LinkedIn + تصاميم Canva Pro", why: "المكتب كان يعتمد على الإحالات فقط — المحتوى الرقمي أصبح مصدراً مستقلاً للعملاء" }
  },
  en: {
    icon: IconShare,
    tag: "Distinctive Presence",
    title: "Social Media Management",
    desc: "We manage your digital presence with strategic content that builds a community of prospects and builds trust in your brand.",
    scope: ["Custom content strategy", "Text and visual content creation", "Professional graphic design", "Organized publishing schedule", "Comment and message management", "Monthly performance reports"],
    features: ["Content targeted to your ideal audience", "Design reflecting your visual identity", "Regular publishing across all platforms", "Fast audience response", "Clear growth reports"],
    results: ["Build strong and consistent presence", "Increase brand awareness", "Audience that converts to clients", "Credibility and professionalism in the market"],
    case: { who: "Emerging real estate office wanting to build a strong digital presence in Jeddah", what: "Instagram + LinkedIn management with 20 posts/month, professional designs, and educational content strategy", when: "Started from zero and reached 5,000 followers in 4 months", where: "Instagram + LinkedIn + Canva Pro designs", why: "The office relied only on referrals — digital content became an independent client source" }
  }
};

export default function ServiceSocial() {
  const { lang } = useOutletContext();
  return (
    <>
      <ServiceDetailPage data={DATA[lang] || DATA.ar} lang={lang} />
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
        <ROICalculator lang={lang} />
      </div>
    </>
  );
}