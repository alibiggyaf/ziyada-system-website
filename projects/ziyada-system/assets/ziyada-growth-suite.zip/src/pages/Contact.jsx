import { useState } from "react";
import { useOutletContext, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";

export default function Contact() {
  const { lang } = useOutletContext();
  const isRTL = lang === "ar";
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", message: "", name: "" });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await base44.functions.invoke("submitLead", { email: form.email, name: form.name, challenge: form.message, source: "contact", language: lang });
      navigate("/ThankYou");
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  const inputStyle = { width: "100%", background: "rgba(255,255,255,0.06)", border: "1px solid var(--border-glass)", borderRadius: 8, padding: "12px 14px", color: "var(--text-primary)", fontFamily: "inherit", fontSize: "0.95rem", outline: "none", boxSizing: "border-box" };

  return (
    <div dir={isRTL ? "rtl" : "ltr"} style={{ maxWidth: 600, margin: "0 auto", padding: "60px 24px" }}>
      <div className="glass-panel" style={{ padding: 48, textAlign: "center" }}>
        <h1 className="gradient-text" style={{ fontSize: "2rem", fontWeight: 900, marginBottom: 12 }}>
          {isRTL ? "تواصل معنا" : "Contact Us"}
        </h1>
        <p style={{ color: "var(--text-secondary)", marginBottom: 32 }}>
          {isRTL ? "للاستفسارات العامة، يرجى ملء النموذج أدناه." : "For general inquiries, please fill out the form below."}
        </p>

        <form onSubmit={handleSubmit} style={{ textAlign: isRTL ? "right" : "left" }}>
            <div style={{ marginBottom: 16 }}>
              <input style={inputStyle} placeholder={isRTL ? "اسمك" : "Your name"} value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} />
            </div>
            <div style={{ marginBottom: 16 }}>
              <input type="email" style={inputStyle} placeholder={isRTL ? "بريدك الإلكتروني" : "Your email"} required value={form.email} onChange={e => setForm(f => ({...f, email: e.target.value}))} />
            </div>
            <div style={{ marginBottom: 20 }}>
              <textarea style={{ ...inputStyle, minHeight: 120, resize: "vertical" }} placeholder={isRTL ? "رسالتك..." : "Your message..."} required value={form.message} onChange={e => setForm(f => ({...f, message: e.target.value}))} />
            </div>
            <button type="submit" className="btn-primary-ziyada" style={{ width: "100%", padding: "14px", fontSize: "1rem" }} disabled={loading}>
              {loading ? "..." : (isRTL ? "إرسال" : "Send")}
            </button>
        </form>
      </div>
    </div>
  );
}