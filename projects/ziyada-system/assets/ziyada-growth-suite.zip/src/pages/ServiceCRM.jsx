import { useOutletContext } from "react-router-dom";
import ServiceDetailPage from "../components/ziyada/ServiceDetailPage.jsx";
import ROICalculator from "../components/ziyada/ROICalculator.jsx";
import { IconTarget } from "../components/ziyada/BrandIcons.jsx";

const DATA = {
  ar: {
    icon: IconTarget,
    tag: "الأعلى ROI",
    title: "هندسة CRM وأتمتة التسويق",
    desc: "نُصمّم ونُنفّذ نظام CRM متكامل يتابع عملاءك المحتملين تلقائياً ويُقصّر دورة البيع.",
    scope: ["إعداد HubSpot / Zoho / Odoo / ClickUp", "تصميم pipelines مبيعات مخصصة", "تقييم ليدز تلقائي + تحويل ذكي", "متابعة بريد + واتساب أوتوماتيك", "لوحات تنفيذية للإدارة", "ربط مع الموقع والإعلانات ون8ن", "تدريب فريق المبيعات"],
    features: ["pipeline مبيعات مخصص للنشاط", "تقييم وتحويل آلي للعملاء المحتملين", "sequences بريد ذكية", "تقارير مبيعات + توقعات دقيقة", "تكامل كامل مع كل القنوات"],
    results: ["صفر فرص ضائعة", "تقليل دورة البيع 25%+", "توقعات إيرادات دقيقة", "إنتاجية فريق أعلى"],
    case: { who: "شركة مقاولات متوسطة بفريق مبيعات من 5 أشخاص", what: "نظام HubSpot مع pipeline مخصص وأتمتة متابعة لكل مرحلة بيع", when: "تم التسليم خلال 4 أسابيع", where: "HubSpot + موقع الشركة + إيميل + واتساب", why: "كانوا يفقدون 40% من العملاء بسبب عدم المتابعة — الأتمتة حلّت هذه المشكلة تماماً" }
  },
  en: {
    icon: IconTarget,
    tag: "Highest ROI",
    title: "CRM Engineering & Marketing Automation",
    desc: "We design and implement an integrated CRM system that automatically follows up on your prospects and shortens your sales cycle.",
    scope: ["Setup HubSpot / Zoho / Odoo / ClickUp", "Custom sales pipeline design", "Auto lead scoring + smart routing", "Automated email + WhatsApp follow-ups", "Executive dashboards for management", "Integration with website, ads, and n8n", "Sales team training"],
    features: ["Custom sales pipeline for your business", "Automated lead scoring and routing", "Smart email sequences", "Sales reports + accurate forecasts", "Full omni-channel integration"],
    results: ["Zero missed opportunities", "25%+ shorter sales cycle", "Accurate revenue forecasts", "Higher team productivity"],
    case: { who: "Mid-size contracting company with a 5-person sales team", what: "HubSpot system with custom pipeline and follow-up automation for every sales stage", when: "Delivered in 4 weeks", where: "HubSpot + Company website + email + WhatsApp", why: "They were losing 40% of leads from lack of follow-up — automation solved this completely" }
  }
};

export default function ServiceCRM() {
  const { lang } = useOutletContext();
  return (
    <>
      <ServiceDetailPage data={DATA[lang] || DATA.ar} lang={lang} />
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
        <ROICalculator lang={lang} />
      </div>
    </>
  );
}