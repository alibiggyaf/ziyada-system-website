import { useOutletContext } from "react-router-dom";
import { Link } from "react-router-dom";
import { IconZap, IconTarget, IconRocket, IconMegaphone, IconGlobe, IconBarChart, IconShare } from "../components/ziyada/BrandIcons";

const C = {
  ar: {
    title: "خدماتنا",
    sub: "منظومة متكاملة من الحلول الرقمية المصمّمة لتضاعف نموّ شركتك",
    cta: "اطلب عرض سعر",
    learn_more: "اعرف أكثر",
    services: [
      { Icon: IconZap,       title: "أتمتة الأعمال",      desc: "بناء سير عمل آلية باستخدام n8n تُوفّر ساعات يومياً وتزيل الأخطاء البشرية وتوصّل كل أنظمتك ببعض.", path: "/Services/automation",      sectors: ["التجزئة", "العقارات", "الرعاية الصحية", "التعليم"] },
      { Icon: IconTarget,    title: "CRM والمبيعات",       desc: "تصميم وهندسة أنظمة HubSpot CRM المتكاملة مع pipelines واضحة وتقارير مبيعات دقيقة.", path: "/Services/crm",             sectors: ["الخدمات المهنية", "التجزئة", "B2B"] },
      { Icon: IconRocket,    title: "توليد العملاء B2B",   desc: "بناء ماكينات توليد عملاء تعمل 24/7 بالجمع بين LinkedIn Outreach والبيانات والأتمتة.", path: "/Services/lead-generation",  sectors: ["التقنية", "الاستشارات", "الخدمات"] },
      { Icon: IconMegaphone, title: "التسويق الرقمي",      desc: "إدارة حملات Google Ads و Meta Ads بعائد استثمار مقيس وإعلانات مصمّمة لتحويل المشاهدين.", path: "/Services/marketing",        sectors: ["التجارة الإلكترونية", "التعليم", "العقارات"] },
      { Icon: IconGlobe,     title: "تطوير المواقع",       desc: "مواقع تحويل عالية الأداء مربوطة بـ CRM وأنظمة تتبع وتحليل متقدمة.", path: "/Services/web-development",  sectors: ["جميع القطاعات"] },
      { Icon: IconBarChart,  title: "SEO & SEM",           desc: "ظهور متصدر في نتائج البحث العضوية والمدفوعة مع تقارير أداء شاملة.", path: "/Services/seo-sem",          sectors: ["التجارة الإلكترونية", "الخدمات", "العقارات"] },
      { Icon: IconShare,     title: "إدارة وسائل التواصل", desc: "إدارة احترافية لحسابات تبني جمهوراً متفاعلاً وتحوّله إلى عملاء فعليين.", path: "/Services/social-media",     sectors: ["التجزئة", "المطاعم", "الرياضة والترفيه"] },
    ]
  },
  en: {
    title: "Our Services",
    sub: "An integrated ecosystem of digital solutions designed to multiply your company's growth",
    cta: "Request a Proposal",
    learn_more: "Learn More",
    services: [
      { Icon: IconZap,       title: "Business Automation",   desc: "Build automated workflows using n8n that save hours daily, eliminate human error, and connect all your systems.", path: "/Services/automation",      sectors: ["Retail", "Real Estate", "Healthcare", "Education"] },
      { Icon: IconTarget,    title: "CRM & Sales",           desc: "Design and engineer integrated HubSpot CRM systems with clear pipelines and precise sales reporting.", path: "/Services/crm",             sectors: ["Professional Services", "Retail", "B2B"] },
      { Icon: IconRocket,    title: "B2B Lead Generation",   desc: "Build 24/7 lead generation machines combining LinkedIn Outreach, data, and automation.", path: "/Services/lead-generation",  sectors: ["Tech", "Consulting", "Services"] },
      { Icon: IconMegaphone, title: "Digital Marketing",     desc: "Manage Google Ads & Meta Ads campaigns with measured ROI and ads designed to convert viewers.", path: "/Services/marketing",        sectors: ["E-commerce", "Education", "Real Estate"] },
      { Icon: IconGlobe,     title: "Web Development",       desc: "High-performance conversion websites linked to CRM and advanced tracking and analytics systems.", path: "/Services/web-development",  sectors: ["All Sectors"] },
      { Icon: IconBarChart,  title: "SEO & SEM",             desc: "Top ranking in organic and paid search results with comprehensive performance reports.", path: "/Services/seo-sem",          sectors: ["E-commerce", "Services", "Real Estate"] },
      { Icon: IconShare,     title: "Social Media Management", desc: "Professional management of accounts that build an engaged audience and convert them to real customers.", path: "/Services/social-media",   sectors: ["Retail", "Restaurants", "Sports & Entertainment"] },
    ]
  }
};

export default function Services() {
  const { lang } = useOutletContext();
  const c = C[lang] || C.ar;
  const isRTL = lang === "ar";

  return (
    <div dir={isRTL ? "rtl" : "ltr"} style={{ maxWidth: 1200, margin: "0 auto", padding: "60px 24px" }}>
      <div style={{ textAlign: "center", maxWidth: 700, margin: "0 auto 60px" }}>
        <h1 className="gradient-text" style={{ fontSize: "2.5rem", fontWeight: 900, marginBottom: 16 }}>{c.title}</h1>
        <p style={{ color: "var(--text-secondary)", fontSize: "1.05rem", lineHeight: 1.8 }}>{c.sub}</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 28, marginBottom: 60 }}>
        {c.services.map((s, i) => (
          <div key={i} className="glass-panel" style={{ padding: 32, display: "flex", flexDirection: "column" }}>
            <div style={{ background: "linear-gradient(135deg,rgba(59,130,246,0.15),rgba(139,92,246,0.15))", borderRadius: 12, padding: 12, display: "inline-flex", marginBottom: 18, color: "var(--accent-primary)", width: "fit-content" }}>
              <s.Icon size={26} />
            </div>
            <h3 style={{ fontWeight: 800, fontSize: "1.15rem", marginBottom: 12 }}>{s.title}</h3>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.92rem", lineHeight: 1.7, flexGrow: 1, marginBottom: 20 }}>{s.desc}</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 20 }}>
              {s.sectors.map((sec, j) => (
                <span key={j} style={{ background: "rgba(59,130,246,0.1)", color: "var(--accent-primary)", fontSize: "0.75rem", padding: "3px 10px", borderRadius: 999, border: "1px solid rgba(59,130,246,0.2)" }}>{sec}</span>
              ))}
            </div>
            <Link to={s.path}>
              <button className="btn-outline-ziyada" style={{ width: "100%", justifyContent: "center", padding: "10px 20px", fontSize: "0.9rem" }}>{c.learn_more} ←</button>
            </Link>
          </div>
        ))}
      </div>

      <div style={{ textAlign: "center" }}>
        <Link to="/RequestProposal">
          <button className="btn-primary-ziyada" style={{ padding: "15px 40px", fontSize: "1rem" }}>{c.cta}</button>
        </Link>
      </div>
    </div>
  );
}