import { useOutletContext } from "react-router-dom";
import ServiceDetailPage from "../components/ziyada/ServiceDetailPage.jsx";
import ROICalculator from "../components/ziyada/ROICalculator.jsx";
import { IconBarChart } from "../components/ziyada/BrandIcons.jsx";

const DATA = {
  ar: {
    icon: IconBarChart,
    tag: "نمو مستدام",
    title: "تحسين محركات البحث SEO وإعلانات البحث SEM",
    desc: "نجعل شركتك في أوّل نتائج Google عضوياً وإعلانياً لاستقطاب عملاء يبحثون عن خدماتك.",
    scope: ["تدقيق SEO الحالي", "بحث الكلمات المفتاحية الاستراتيجية", "تحسين On-page وOff-page", "بناء روابط خارجية موثوقة", "إدارة حملات Google Search"],
    features: ["تقارير ترتيب أسبوعية", "تحسين مستمر للمحتوى", "حملات Google Ads محسّنة", "استهداف جغرافي دقيق", "قياس الترافيك والتحويلات"],
    results: ["ترافيك عضوي مجاني ومستدام", "عملاء يأتون وهم يبحثون عنك", "تقليل الاعتماد على الإعلانات المدفوعة", "ظهور قوي ومستمر في Google"],
    case: { who: "شركة مقاولات تبحث عن مشاريع تجارية وحكومية", what: "حملة SEO مع 20 صفحة محتوى مُحسَّنة + Google Ads على 50 كلمة مفتاحية عالية القيمة", when: "نتائج SEO ظهرت خلال 3-4 أشهر، Google Ads فورية", where: "موقع الشركة + Google Search Console + Google Ads", why: "لم تكن الشركة تظهر في Google أبداً — الآن تحتل الصفحة الأولى لـ 30+ كلمة مفتاحية" }
  },
  en: {
    icon: IconBarChart,
    tag: "Sustainable Growth",
    title: "SEO & Search Engine Advertising (SEM)",
    desc: "We get your company to the top of Google results organically and through ads to attract clients who are already searching for your services.",
    scope: ["Current SEO audit", "Strategic keyword research", "On-page and off-page optimization", "Building trusted backlinks", "Google Search campaign management"],
    features: ["Weekly ranking reports", "Continuous content optimization", "Optimized Google Ads campaigns", "Precise geographic targeting", "Traffic and conversion measurement"],
    results: ["Free and sustainable organic traffic", "Clients come already looking for you", "Reduced dependence on paid ads", "Strong and continuous visibility on Google"],
    case: { who: "Contracting company looking for commercial and government projects", what: "SEO campaign with 20 optimized content pages + Google Ads on 50 high-value keywords", when: "SEO results appeared within 3-4 months, Google Ads immediately", where: "Company website + Google Search Console + Google Ads", why: "Company didn't appear on Google at all — now ranks page 1 for 30+ keywords" }
  }
};

export default function ServiceSEO() {
  const { lang } = useOutletContext();
  return (
    <>
      <ServiceDetailPage data={DATA[lang] || DATA.ar} lang={lang} />
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
        <ROICalculator lang={lang} />
      </div>
    </>
  );
}