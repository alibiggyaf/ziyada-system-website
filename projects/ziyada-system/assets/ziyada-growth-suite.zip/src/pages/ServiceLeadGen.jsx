import { useOutletContext } from "react-router-dom";
import ServiceDetailPage from "../components/ziyada/ServiceDetailPage.jsx";
import ROICalculator from "../components/ziyada/ROICalculator.jsx";
import { IconRocket } from "../components/ziyada/BrandIcons.jsx";

const DATA = {
  ar: {
    icon: IconRocket,
    tag: "نتائج سريعة",
    title: "منظومة توليد العملاء B2B",
    desc: "نبني لك ماكينة توليد عملاء مؤهّلين بشكل مستمر باستخدام الأتمتة والبيانات.",
    scope: ["بناء ICP دقيق (Customer Profile)", "LinkedIn Outreach مؤتمتة", "Cold Email sequences متخصصة", "ربط مع HubSpot تلقائياً", "متابعة 7 خطوات أوتوماتيك", "تقارير أسبوعية للأداء", "تحسين مستمر للرسائل"],
    features: ["+50 ليد مؤهل شهرياً", "نمو إيرادات 40%", "تحسين التحويل 35%", "تقليل تكلفة الليد بـ 60%", "تصنيف وتقييم الليدز آلياً"],
    results: ["+50 ليد/شهر", "نمو 40% إيرادات", "تحويل 35% أعلى", "متابعة آلية كاملة"],
    case: { who: "شركة SaaS تستهدف الشركات المتوسطة والكبيرة في السعودية", what: "نظام توليد عملاء يشمل LinkedIn Ads + صفحة هبوط + CRM + سلسلة إيميلات أتمتة", when: "خلال شهر واحد من الإطلاق بدأت تصل leads مؤهلة", where: "LinkedIn + Google Ads + HubSpot + البريد الإلكتروني", why: "كانت المبيعات تعتمد على العلاقات الشخصية فقط — الآن 60% من الصفقات تأتي من الأنظمة الرقمية" }
  },
  en: {
    icon: IconRocket,
    tag: "Fast Results",
    title: "B2B Lead Generation System",
    desc: "We build a continuous machine for qualified leads using automation and data.",
    scope: ["Build precise ICP (Customer Profile)", "Automated LinkedIn Outreach", "Specialized cold email sequences", "Auto-connect to HubSpot", "7-step automated follow-up", "Weekly performance reports", "Continuous message optimization"],
    features: ["+50 qualified leads/month", "40% revenue growth", "35% conversion improvement", "60% reduction in lead cost", "Automated lead scoring and classification"],
    results: ["+50 leads/month", "40% revenue growth", "35% higher conversion", "Full automated follow-up"],
    case: { who: "SaaS company targeting mid and large enterprises in Saudi Arabia", what: "Lead gen system with LinkedIn Ads + landing page + CRM + email automation sequences", when: "Qualified leads started arriving within one month of launch", where: "LinkedIn + Google Ads + HubSpot + Email", why: "Sales relied only on personal connections — now 60% of deals come from digital systems" }
  }
};

export default function ServiceLeadGen() {
  const { lang } = useOutletContext();
  return (
    <>
      <ServiceDetailPage data={DATA[lang] || DATA.ar} lang={lang} />
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
        <ROICalculator lang={lang} />
      </div>
    </>
  );
}