import { useOutletContext } from "react-router-dom";
import ServiceDetailPage from "../components/ziyada/ServiceDetailPage.jsx";
import ROICalculator from "../components/ziyada/ROICalculator.jsx";
import { IconMegaphone } from "../components/ziyada/BrandIcons.jsx";

const DATA = {
  ar: {
    icon: IconMegaphone,
    tag: "ROI أعلى",
    title: "إدارة الحملات الإعلانية والتسويق الرقمي",
    desc: "نُدير حملاتك الإعلانية بمنهجية بيانات واضحة لتحقيق أعلى عائد على الإنفاق الإعلاني.",
    scope: ["إعداد استراتيجية الحملة", "بناء الجماهير المستهدفة", "إنشاء الإعلانات والمحتوى", "إدارة الميزانيات والعروض", "تحسين مستمر وتقارير تفصيلية"],
    features: ["Google Ads + Meta Ads + Snapchat", "استهداف دقيق للجمهور", "A/B testing للإعلانات", "تحسين مستمر للأداء", "تقارير ROAS واضحة"],
    results: ["زيادة ROAS بـ 2x-4x", "تخفيض تكلفة الاستحواذ", "جمهور موسّع ومؤهّل", "رؤية واضحة لكل ريال يُنفَق"],
    case: { who: "مطوّر عقاري في جدة يطلق مشروع سكني 150 وحدة", what: "حملة Google + Meta موجّهة لمستهدفين بالدخل والاهتمامات مع صفحة هبوط محسّنة", when: "حملة 3 أشهر بميزانية 50,000 ريال شهرياً", where: "Google Search + Meta (Facebook/Instagram) + صفحة هبوط مخصصة", why: "المبيعات عبر الأدوات التقليدية كانت بطيئة — الحملة الرقمية أنتجت 80 عميل مؤهّل في الشهر الأول" }
  },
  en: {
    icon: IconMegaphone,
    tag: "Higher ROI",
    title: "Ad Campaign Management & Digital Marketing",
    desc: "We manage your ad campaigns with a clear data methodology to achieve the highest return on ad spend.",
    scope: ["Campaign strategy setup", "Target audience building", "Ad and content creation", "Budget and bid management", "Continuous optimization and detailed reports"],
    features: ["Google Ads + Meta Ads + Snapchat", "Precise audience targeting", "A/B testing for ads", "Continuous performance optimization", "Clear ROAS reports"],
    results: ["2x–4x ROAS increase", "Reduced acquisition cost", "Broader qualified audience", "Clear visibility on every dollar spent"],
    case: { who: "Real estate developer in Jeddah launching a 150-unit residential project", what: "Google + Meta campaign targeting by income and interest with an optimized landing page", when: "3-month campaign at 50,000 SAR/month budget", where: "Google Search + Meta (Facebook/Instagram) + custom landing page", why: "Traditional sales tools were slow — the digital campaign generated 80 qualified leads in the first month" }
  }
};

export default function ServiceMarketing() {
  const { lang } = useOutletContext();
  return (
    <>
      <ServiceDetailPage data={DATA[lang] || DATA.ar} lang={lang} />
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
        <ROICalculator lang={lang} />
      </div>
    </>
  );
}