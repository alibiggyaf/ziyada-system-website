import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Users, Calendar, BookOpen, Mail, TrendingUp, Trash2, Eye } from "lucide-react";

const TABS = [
  { id: "leads", label: "Leads", icon: Users },
  { id: "bookings", label: "Bookings", icon: Calendar },
  { id: "blog", label: "Blog Posts", icon: BookOpen },
  { id: "subscribers", label: "Subscribers", icon: Mail },
];

const STATUS_COLORS = { new: "#f59e0b", contacted: "#3b82f6", qualified: "#8b5cf6", closed: "#22c55e", pending: "#f59e0b", confirmed: "#22c55e", cancelled: "#ef4444", published: "#22c55e", draft: "#9ca3af", active: "#22c55e", unsubscribed: "#9ca3af" };

export default function AdminDashboard() {
  const [tab, setTab] = useState("leads");
  const qc = useQueryClient();

  const { data: leads = [] } = useQuery({ queryKey: ["admin_leads"], queryFn: () => base44.entities.Lead.list("-created_date", 100) });
  const { data: bookings = [] } = useQuery({ queryKey: ["admin_bookings"], queryFn: () => base44.entities.Booking.list("-created_date", 100) });
  const { data: posts = [] } = useQuery({ queryKey: ["admin_posts"], queryFn: () => base44.entities.BlogPost.list("-created_date", 100) });
  const { data: subscribers = [] } = useQuery({ queryKey: ["admin_subs"], queryFn: () => base44.entities.Subscriber.list("-created_date", 100) });

  const deleteLead = useMutation({ mutationFn: id => base44.entities.Lead.delete(id), onSuccess: () => qc.invalidateQueries(["admin_leads"]) });
  const deleteBooking = useMutation({ mutationFn: id => base44.entities.Booking.delete(id), onSuccess: () => qc.invalidateQueries(["admin_bookings"]) });
  const deletePost = useMutation({ mutationFn: id => base44.entities.BlogPost.delete(id), onSuccess: () => qc.invalidateQueries(["admin_posts"]) });

  const updatePostStatus = useMutation({
    mutationFn: ({ id, status }) => base44.entities.BlogPost.update(id, { status }),
    onSuccess: () => qc.invalidateQueries(["admin_posts"])
  });

  const tableStyle = { width: "100%", borderCollapse: "collapse" };
  const thStyle = { padding: "10px 14px", textAlign: "left", fontSize: "0.8rem", color: "var(--text-secondary)", borderBottom: "1px solid var(--border-glass)", fontWeight: 700, textTransform: "uppercase" };
  const tdStyle = { padding: "12px 14px", fontSize: "0.88rem", borderBottom: "1px solid rgba(255,255,255,0.04)", color: "var(--text-primary)", verticalAlign: "top" };

  const Badge = ({ status }) => (
    <span style={{ background: `${STATUS_COLORS[status] || "#6b7280"}20`, color: STATUS_COLORS[status] || "#6b7280", padding: "2px 8px", borderRadius: 999, fontSize: "0.75rem", fontWeight: 700 }}>
      {status}
    </span>
  );

  const stats = [
    { label: "Total Leads", value: leads.length, icon: Users, color: "#7c3aed" },
    { label: "Bookings", value: bookings.length, icon: Calendar, color: "#06b6d4" },
    { label: "Blog Posts", value: posts.length, icon: BookOpen, color: "#f59e0b" },
    { label: "Subscribers", value: subscribers.length, icon: Mail, color: "#22c55e" },
  ];

  return (
    <div style={{ maxWidth: 1400, margin: "0 auto", padding: "40px 24px" }}>
      <h1 style={{ fontWeight: 900, fontSize: "1.8rem", marginBottom: 8 }}>Admin Dashboard</h1>
      <p style={{ color: "var(--text-secondary)", marginBottom: 32, fontSize: "0.9rem" }}>Ziyada Systems — Internal Management</p>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: 36 }}>
        {stats.map(s => (
          <div key={s.label} className="glass-panel" style={{ padding: 20, display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 44, height: 44, borderRadius: 10, background: `${s.color}20`, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <s.icon size={20} style={{ color: s.color }} />
            </div>
            <div>
              <div style={{ fontSize: "1.6rem", fontWeight: 900 }}>{s.value}</div>
              <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)" }}>{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 4, marginBottom: 24, borderBottom: "1px solid var(--border-glass)", paddingBottom: 0 }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{ padding: "10px 18px", background: "none", border: "none", cursor: "pointer", fontSize: "0.9rem", fontWeight: 600, color: tab === t.id ? "var(--accent-primary)" : "var(--text-secondary)", borderBottom: `2px solid ${tab === t.id ? "var(--accent-primary)" : "transparent"}`, display: "flex", alignItems: "center", gap: 6, fontFamily: "inherit" }}>
            <t.icon size={15} />{t.label}
          </button>
        ))}
      </div>

      {/* Leads */}
      {tab === "leads" && (
        <div className="glass-panel" style={{ overflow: "auto" }}>
          <table style={tableStyle}>
            <thead><tr>
              {["Name","Email","Company","Source","Status","Date","Actions"].map(h => <th key={h} style={thStyle}>{h}</th>)}
            </tr></thead>
            <tbody>
              {leads.map(lead => (
                <tr key={lead.id}>
                  <td style={tdStyle}>{lead.name || "—"}</td>
                  <td style={tdStyle}>{lead.email}</td>
                  <td style={tdStyle}>{lead.company || "—"}</td>
                  <td style={tdStyle}><Badge status={lead.source} /></td>
                  <td style={tdStyle}><Badge status={lead.status} /></td>
                  <td style={tdStyle}>{lead.created_date?.split("T")[0]}</td>
                  <td style={tdStyle}>
                    <button onClick={() => deleteLead.mutate(lead.id)} style={{ background: "none", border: "none", cursor: "pointer", color: "#ef4444" }}><Trash2 size={14} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {leads.length === 0 && <p style={{ textAlign: "center", padding: 40, color: "var(--text-secondary)" }}>No leads yet.</p>}
        </div>
      )}

      {/* Bookings */}
      {tab === "bookings" && (
        <div className="glass-panel" style={{ overflow: "auto" }}>
          <table style={tableStyle}>
            <thead><tr>
              {["Name","Email","Company","Date","Time","Status","Meet Link","Actions"].map(h => <th key={h} style={thStyle}>{h}</th>)}
            </tr></thead>
            <tbody>
              {bookings.map(b => (
                <tr key={b.id}>
                  <td style={tdStyle}>{b.lead_name}</td>
                  <td style={tdStyle}>{b.lead_email}</td>
                  <td style={tdStyle}>{b.company || "—"}</td>
                  <td style={tdStyle}>{b.booking_date}</td>
                  <td style={tdStyle}>{b.booking_time}</td>
                  <td style={tdStyle}><Badge status={b.status} /></td>
                  <td style={tdStyle}>{b.google_meet_link ? <a href={b.google_meet_link} target="_blank" rel="noreferrer" style={{ color: "var(--accent-primary)", fontSize: "0.8rem" }}>Open</a> : "—"}</td>
                  <td style={tdStyle}>
                    <button onClick={() => deleteBooking.mutate(b.id)} style={{ background: "none", border: "none", cursor: "pointer", color: "#ef4444" }}><Trash2 size={14} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {bookings.length === 0 && <p style={{ textAlign: "center", padding: 40, color: "var(--text-secondary)" }}>No bookings yet.</p>}
        </div>
      )}

      {/* Blog */}
      {tab === "blog" && (
        <div className="glass-panel" style={{ overflow: "auto" }}>
          <div style={{ padding: 16, borderBottom: "1px solid var(--border-glass)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ color: "var(--text-secondary)", fontSize: "0.85rem" }}>Posts are auto-published via n8n webhook. See <code style={{ color: "var(--accent-primary)" }}>functions/n8nWebhook</code> for integration details.</span>
          </div>
          <table style={tableStyle}>
            <thead><tr>
              {["Title (AR)","Title (EN)","Status","Published Date","Author","Actions"].map(h => <th key={h} style={thStyle}>{h}</th>)}
            </tr></thead>
            <tbody>
              {posts.map(p => (
                <tr key={p.id}>
                  <td style={tdStyle}>{p.title_ar}</td>
                  <td style={tdStyle}>{p.title_en}</td>
                  <td style={tdStyle}>
                    <select value={p.status} onChange={e => updatePostStatus.mutate({ id: p.id, status: e.target.value })}
                      style={{ background: "var(--bg-card)", border: "1px solid var(--border-glass)", borderRadius: 4, padding: "2px 6px", color: "var(--text-primary)", fontSize: "0.8rem", fontFamily: "inherit", cursor: "pointer" }}>
                      <option value="draft">draft</option>
                      <option value="published">published</option>
                    </select>
                  </td>
                  <td style={tdStyle}>{p.published_date || "—"}</td>
                  <td style={tdStyle}>{p.author || "—"}</td>
                  <td style={tdStyle}>
                    <button onClick={() => deletePost.mutate(p.id)} style={{ background: "none", border: "none", cursor: "pointer", color: "#ef4444" }}><Trash2 size={14} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {posts.length === 0 && <p style={{ textAlign: "center", padding: 40, color: "var(--text-secondary)" }}>No blog posts yet. Use the n8n webhook to publish.</p>}
        </div>
      )}

      {/* Subscribers */}
      {tab === "subscribers" && (
        <div className="glass-panel" style={{ overflow: "auto" }}>
          <table style={tableStyle}>
            <thead><tr>
              {["Email","Name","Language","Status","Welcome Sent","Date"].map(h => <th key={h} style={thStyle}>{h}</th>)}
            </tr></thead>
            <tbody>
              {subscribers.map(s => (
                <tr key={s.id}>
                  <td style={tdStyle}>{s.email}</td>
                  <td style={tdStyle}>{s.name || "—"}</td>
                  <td style={tdStyle}>{s.language}</td>
                  <td style={tdStyle}><Badge status={s.status} /></td>
                  <td style={tdStyle}>{s.welcome_email_sent ? "✓" : "—"}</td>
                  <td style={tdStyle}>{s.created_date?.split("T")[0]}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {subscribers.length === 0 && <p style={{ textAlign: "center", padding: 40, color: "var(--text-secondary)" }}>No subscribers yet.</p>}
        </div>
      )}
    </div>
  );
}