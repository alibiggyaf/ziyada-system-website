import { useOutletContext } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import { Calendar, ArrowLeft, ArrowRight } from "lucide-react";
import { staticPosts } from "./blogContent";

export default function BlogPost() {
  const { lang } = useOutletContext();
  const isRTL = lang === "ar";
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");
  const slug = params.get("slug");

  const { data: dbPost, isLoading } = useQuery({
    queryKey: ["blog_post", id, slug],
    queryFn: async () => {
      if (id) {
        const res = await base44.entities.BlogPost.filter({ id });
        return res?.[0] || null;
      }
      return null;
    },
    enabled: !!id,
  });

  // If no DB post found (or loading a slug), fall back to static content
  const staticPost = slug ? staticPosts.find(p => p.slug === slug) : null;
  const post = dbPost || staticPost;

  const Arrow = isRTL ? ArrowRight : ArrowLeft;

  if (isLoading) return (
    <div style={{ maxWidth: 800, margin: "60px auto", padding: "0 24px" }}>
      <div className="glass-panel" style={{ padding: 40, height: 400 }} />
    </div>
  );

  if (!post) return (
    <div dir={isRTL ? "rtl" : "ltr"} style={{ maxWidth: 800, margin: "60px auto", padding: "0 24px", textAlign: "center" }}>
      <p style={{ color: "var(--text-secondary)" }}>{isRTL ? "المقال غير موجود" : "Post not found"}</p>
      <Link to="/Blog"><button className="btn-outline-ziyada" style={{ marginTop: 20 }}>{isRTL ? "العودة للمدونة" : "Back to Blog"}</button></Link>
    </div>
  );

  return (
    <div dir={isRTL ? "rtl" : "ltr"} style={{ maxWidth: 800, margin: "0 auto", padding: "60px 24px" }}>
      <Link to="/Blog" style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--text-secondary)", textDecoration: "none", marginBottom: 32, fontSize: "0.9rem" }}>
        <Arrow size={16} /> {isRTL ? "العودة للمدونة" : "Back to Blog"}
      </Link>

      {post.cover_image && (
        <img src={post.cover_image} alt={isRTL ? post.title_ar : post.title_en} style={{ width: "100%", height: 320, objectFit: "cover", borderRadius: 12, marginBottom: 36 }} />
      )}

      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
        {post.tags?.map(t => (
          <span key={t} style={{ background: "rgba(124,58,237,0.15)", color: "var(--accent-primary)", fontSize: "0.8rem", padding: "3px 10px", borderRadius: 999 }}>{t}</span>
        ))}
      </div>

      <h1 style={{ fontSize: "2.2rem", fontWeight: 900, marginBottom: 12, lineHeight: 1.3 }}>
        {isRTL ? post.title_ar : post.title_en}
      </h1>
      <div style={{ display: "flex", alignItems: "center", gap: 12, color: "var(--text-secondary)", fontSize: "0.85rem", marginBottom: 36 }}>
        <Calendar size={14} />{post.published_date}
        {post.author && <span>— {post.author}</span>}
      </div>

      <div style={{ color: "var(--text-secondary)", lineHeight: 1.9, fontSize: "1.05rem" }}>
        <ReactMarkdown>{isRTL ? post.content_ar : post.content_en}</ReactMarkdown>
      </div>
    </div>
  );
}