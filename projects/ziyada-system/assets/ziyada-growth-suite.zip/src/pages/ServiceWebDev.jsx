import { useOutletContext } from 'react-router-dom';
import ServiceDetailPage from '@/components/ziyada/ServiceDetailPage';
import ROICalculator from '@/components/ziyada/ROICalculator';
import { IconGlobe } from '@/components/ziyada/BrandIcons';

export default function ServiceWebDev() {
  const { lang } = useOutletContext() || { lang: 'ar' };

  const data = lang === 'ar' ? {
    icon: IconGlobe,
    tag: 'تطوير مواقع وتطبيقات',
    title: 'تطوير مواقع وتطبيقات احترافية',
    desc: 'نبني لك موقع ويب أو تطبيق يعكس احترافيتك ويحول الزوار لعملاء.',
    scope: [
      'تصميم UX/UI احترافي وسهل الاستخدام',
      'تطوير الواجهة الأمامية (Frontend) باستخدام أحدث التقنيات',
      'تطوير الخادم والقواعد البيانات (Backend)',
      'تكامل الدفع الإلكتروني والخدمات الثالثة',
      'تحسين الأداء وسرعة التحميل',
      'الاستجابة الكاملة لجميع الأجهزة (Mobile-First)',
      'اختبار شامل وضمان الجودة',
      'نشر واستضافة احترافية'
    ],
    features: [
      'واجهة مستخدم حديثة وجذابة',
      'سرعة تحميل سريعة جداً (صفحات تحميل في أقل من ثانية)',
      'آمان عالي مع تشفير SSL',
      'سهولة الصيانة والتحديث',
      'مدعوم بتحليلات قوية',
      'SEO محسّن من البداية',
      'نسخ احتياطية تلقائية'
    ],
    results: [
      '+200% زيادة التحويلات',
      '-60% انخفاض معدل الارتجاع',
      '+150% زيادة الوقت في الموقع',
      '+300% زيادة العملاء المتكررين'
    ],
    case: {
      who: 'شركة عقارية متوسطة تبحث عن تحضير رقمي',
      what: 'طورنا بوابة عقارية متكاملة مع خريطة، بحث متقدم، وأتمتة الحجوزات',
      when: '3 أشهر من التطوير',
      where: 'المملكة العربية السعودية',
      why: 'زيادة البيعات الرقمية والتواصل المباشر مع المشترين'
    }
  } : {
    icon: IconGlobe,
    tag: 'Web & App Development',
    title: 'Professional Web & App Development',
    desc: 'We build a website or app that reflects your professionalism and converts visitors into customers.',
    scope: [
      'Professional UX/UI design with ease of use',
      'Frontend development using latest technologies',
      'Backend development and database design',
      'Payment integration and third-party services',
      'Performance optimization and fast loading',
      'Full responsiveness across all devices (Mobile-First)',
      'Comprehensive testing and quality assurance',
      'Professional deployment and hosting'
    ],
    features: [
      'Modern and attractive user interface',
      'Ultra-fast loading speeds (pages load in under 1 second)',
      'High security with SSL encryption',
      'Easy maintenance and updates',
      'Powerful analytics integration',
      'SEO optimized from the start',
      'Automatic backups'
    ],
    results: [
      '+200% Conversion Increase',
      '-60% Bounce Rate Drop',
      '+150% Time on Site',
      '+300% Repeat Customer Growth'
    ],
    case: {
      who: 'Mid-sized real estate firm seeking digital transformation',
      what: 'We developed an integrated real estate portal with maps, advanced search, and automated booking',
      when: '3 months of development',
      where: 'Saudi Arabia',
      why: 'Increase digital sales and direct communication with buyers'
    }
  };

  return (
    <div style={{ paddingTop: 80 }}>
      <ServiceDetailPage data={data} lang={lang} />
      <ROICalculator lang={lang} />
    </div>
  );
}