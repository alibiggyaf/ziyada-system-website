import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

// Layout
import ZiyadaLayout from './components/ziyada/Layout';

// Pages
import Home from './pages/Home';
import Services from './pages/Services';
import About from './pages/About';
import Why from './pages/Why';
import Cases from './pages/Cases';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import BookMeeting from './pages/BookMeeting';
import RequestProposal from './pages/RequestProposal';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';
import AdminDashboard from './pages/AdminDashboard';
import ServiceAutomation from './pages/ServiceAutomation';
import ServiceCRM from './pages/ServiceCRM';
import ServiceLeadGen from './pages/ServiceLeadGen';
import ServiceMarketing from './pages/ServiceMarketing';
import ServiceWebDev from './pages/ServiceWebDev';
import ServiceSEO from './pages/ServiceSEO';
import ServiceSocial from './pages/ServiceSocial';
import FAQ from './pages/FAQ';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center" style={{ background: "#0a0a0f" }}>
        <div className="w-8 h-8 border-4 border-purple-900 border-t-purple-400 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') return <UserNotRegisteredError />;
    else if (authError.type === 'auth_required') { navigateToLogin(); return null; }
  }

  return (
    <Routes>
      <Route path="/" element={<Navigate to="/Home" replace />} />

      {/* Public site with shared layout */}
      <Route element={<ZiyadaLayout />}>
        <Route path="/Home" element={<Home />} />
        <Route path="/Services" element={<Services />} />
        <Route path="/About" element={<About />} />
        <Route path="/Why" element={<Why />} />
        <Route path="/Cases" element={<Cases />} />
        <Route path="/Blog" element={<Blog />} />
        <Route path="/BlogPost" element={<BlogPost />} />
        <Route path="/BookMeeting" element={<BookMeeting />} />
        <Route path="/RequestProposal" element={<RequestProposal />} />
        <Route path="/Contact" element={<Contact />} />
        <Route path="/ThankYou" element={<ThankYou />} />
        <Route path="/Privacy" element={<Privacy />} />
        <Route path="/Terms" element={<Terms />} />
        <Route path="/Services/automation" element={<ServiceAutomation />} />
        <Route path="/Services/crm" element={<ServiceCRM />} />
        <Route path="/Services/lead-generation" element={<ServiceLeadGen />} />
        <Route path="/Services/marketing" element={<ServiceMarketing />} />
        <Route path="/Services/web-development" element={<ServiceWebDev />} />
        <Route path="/Services/seo-sem" element={<ServiceSEO />} />
        <Route path="/Services/social-media" element={<ServiceSocial />} />
        <Route path="/FAQ" element={<FAQ />} />
      </Route>

      {/* Admin — no layout wrapping */}
      <Route path="/AdminDashboard" element={<AdminDashboard />} />

      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App