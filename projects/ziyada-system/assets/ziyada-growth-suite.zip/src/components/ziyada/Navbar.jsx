import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Moon, Sun, Menu, X, Globe } from "lucide-react";

const NAV = {
  ar: [
    { label: "الرئيسية", path: "/Home" },
    { label: "لماذا زيادة", path: "/Why" },
    { label: "خدماتنا", path: "/Services" },
    { label: "من نحن", path: "/About" },
    { label: "قصص النجاح", path: "/Cases" },
    { label: "المدونة", path: "/Blog" },
  ],
  en: [
    { label: "Home", path: "/Home" },
    { label: "Why Ziyada", path: "/Why" },
    { label: "Services", path: "/Services" },
    { label: "About", path: "/About" },
    { label: "Success Stories", path: "/Cases" },
    { label: "Blog", path: "/Blog" },
  ]
};

export default function Navbar({ lang, toggleLang, theme, toggleTheme, isRTL: _isRTL }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  const isRTL = lang === "ar";

  return (
    <header style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
      background: theme === "dark" ? "rgba(10,10,15,0.88)" : "rgba(240,240,248,0.92)",
      backdropFilter: "blur(12px)",
      borderBottom: "1px solid var(--border-glass)"
    }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 }}
        dir={isRTL ? "rtl" : "ltr"}>
        {/* Logo */}
        <Link to="/Home" style={{ textDecoration: "none" }}>
          <span className="gradient-text" style={{ fontSize: "1.3rem", fontWeight: 900, letterSpacing: "-0.02em" }}>
            Ziyada Systems
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav style={{ display: "flex", gap: 28, listStyle: "none" }} className="hidden-mobile">
          {NAV[lang].map(item => (
            <Link key={item.path} to={item.path} style={{
              textDecoration: "none", fontSize: "0.9rem", fontWeight: 600,
              color: location.pathname === item.path ? "var(--accent-primary)" : "var(--text-secondary)",
              transition: "color 0.2s"
            }}>
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Controls */}
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button onClick={toggleTheme}
            style={{ background: "rgba(255,255,255,0.08)", border: "1px solid var(--border-glass)", borderRadius: 8, padding: "6px 10px", cursor: "pointer", color: "var(--text-primary)" }}>
            {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
          </button>
          <button onClick={toggleLang}
            style={{ background: "rgba(255,255,255,0.08)", border: "1px solid var(--border-glass)", borderRadius: 8, padding: "6px 12px", cursor: "pointer", color: "var(--text-primary)", fontSize: "0.85rem", fontWeight: 700, display: "flex", alignItems: "center", gap: 4 }}>
            <Globe size={14} /> {lang === "ar" ? "EN" : "AR"}
          </button>
          <Link to="/BookMeeting" className="nav-cta-link">
            <button className="btn-cta">
              {lang === "ar" ? "احجز استشارة" : "Book Consultation"}
            </button>
          </Link>
          <button onClick={() => setMobileOpen(o => !o)}
            style={{ background: "transparent", border: "none", cursor: "pointer", color: "var(--text-primary)", display: "none" }}
            className="mobile-menu-btn">
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {mobileOpen && (
        <div style={{ background: "var(--bg-surface)", borderBottom: "1px solid var(--border-glass)", padding: "16px 24px" }}
          dir={isRTL ? "rtl" : "ltr"}>
          {NAV[lang].map(item => (
            <Link key={item.path} to={item.path}
              onClick={() => setMobileOpen(false)}
              style={{ display: "block", padding: "10px 0", textDecoration: "none", color: "var(--text-secondary)", fontWeight: 600, borderBottom: "1px solid var(--border-glass)" }}>
              {item.label}
            </Link>
          ))}
        </div>
      )}

      <style>{`
        @media (max-width: 768px) {
          .hidden-mobile { display: none !important; }
          .mobile-menu-btn { display: flex !important; }
        }

        .btn-cta { white-space: nowrap; }
      `}</style>
    </header>
  );
}