import { useEffect } from "react";

/**
 * Analytics — injects GA4, Meta Pixel, and Hotjar scripts once.
 *
 * ┌─────────────────────────────────────────────────────────────────┐
 * │  HOW TO ACTIVATE:                                               │
 * │  Replace the placeholder IDs below with your real IDs:          │
 * │                                                                  │
 * │  GA4_ID    → Measurement ID from Google Analytics 4             │
 * │              e.g. "G-ABC123XYZ"                                 │
 * │  PIXEL_ID  → Pixel ID from Meta Business Manager                │
 * │              e.g. "1234567890123456"                            │
 * │  HOTJAR_ID → Site ID from Hotjar dashboard                      │
 * │              e.g. 1234567                                       │
 * └─────────────────────────────────────────────────────────────────┘
 */

const GA4_ID    = "G-XXXXXXXXXX";       // ← استبدل بـ Measurement ID
const PIXEL_ID  = "XXXXXXXXXXXXXXXX";   // ← استبدل بـ Meta Pixel ID
const HOTJAR_ID = "XXXXXXX";            // ← استبدل بـ Hotjar Site ID (رقم)

function injectScript(id, src, onload) {
  if (document.getElementById(id)) return;
  const s = document.createElement("script");
  s.id = id; s.src = src; s.async = true;
  if (onload) s.onload = onload;
  document.head.appendChild(s);
}

function injectInlineScript(id, code) {
  if (document.getElementById(id)) return;
  const s = document.createElement("script");
  s.id = id; s.innerHTML = code;
  document.head.appendChild(s);
}

export default function Analytics() {
  useEffect(() => {
    /* ── Google Analytics 4 ── */
    if (!GA4_ID.includes("X")) {
      injectScript("ga4-script", `https://www.googletagmanager.com/gtag/js?id=${GA4_ID}`, () => {
        injectInlineScript("ga4-config", `
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', '${GA4_ID}');
        `);
      });
    }

    /* ── Meta Pixel ── */
    if (!PIXEL_ID.includes("X")) {
      injectInlineScript("meta-pixel", `
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window, document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '${PIXEL_ID}');
        fbq('track', 'PageView');
      `);
    }

    /* ── Hotjar ── */
    if (!HOTJAR_ID.includes("X")) {
      injectInlineScript("hotjar", `
        (function(h,o,t,j,a,r){
          h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
          h._hjSettings={hjid:${HOTJAR_ID},hjsv:6};
          a=o.getElementsByTagName('head')[0];
          r=o.createElement('script');r.async=1;
          r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
          a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
      `);
    }
  }, []);

  return null;
}