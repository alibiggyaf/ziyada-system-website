import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import GlassPanel from '../ziyada/GlassPanel';
import { Video, Calendar, Clock, Mail, Building, Trash2 } from 'lucide-react';

const statusColors = { pending: '#f59e0b', confirmed: '#10b981', cancelled: '#ef4444' };

export default function AdminBookings({ lang }) {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    base44.entities.Booking.list('-created_date', 100).then(setBookings);
  }, []);

  const updateStatus = async (id, status) => {
    await base44.entities.Booking.update(id, { status });
    setBookings(prev => prev.map(b => b.id === id ? { ...b, status } : b));
  };

  const deleteBooking = async (id) => {
    await base44.entities.Booking.delete(id);
    setBookings(prev => prev.filter(b => b.id !== id));
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {bookings.map(b => (
        <GlassPanel key={b.id} style={{ padding: '20px 24px' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10, flexWrap: 'wrap' }}>
                <span style={{ fontWeight: 700 }}>{b.lead_name || b.name}</span>
                <span style={{ fontSize: '0.75rem', padding: '2px 10px', borderRadius: 20, background: `${statusColors[b.status]}22`, color: statusColors[b.status], border: `1px solid ${statusColors[b.status]}44`, fontWeight: 700 }}>{b.status}</span>
              </div>
              <div style={{ display: 'flex', gap: 16, fontSize: '0.85rem', color: 'rgba(255,255,255,0.55)', flexWrap: 'wrap', marginBottom: 10 }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Mail size={13} />{b.lead_email || b.email}</span>
                <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Calendar size={13} />{b.booking_date}</span>
                <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Clock size={13} />{b.booking_time}</span>
                {b.company && <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Building size={13} />{b.company}</span>}
              </div>
              {b.google_meet_link && (
                <a href={b.google_meet_link} target="_blank" rel="noopener noreferrer"
                  style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: '0.85rem', color: '#8b5cf6', textDecoration: 'none', fontWeight: 600 }}>
                  <Video size={14} /> Google Meet
                </a>
              )}
              {b.hubspot_deal_id && <span style={{ marginLeft: 12, fontSize: '0.75rem', color: '#06b6d4' }}>HubSpot Deal ✓</span>}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <select value={b.status} onChange={e => updateStatus(b.id, e.target.value)}
                style={{ padding: '6px 10px', borderRadius: 8, background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)', color: '#fff', fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'inherit' }}>
                {['pending', 'confirmed', 'cancelled'].map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <button onClick={() => deleteBooking(b.id)} style={{ background: 'rgba(239,68,68,0.15)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 8, padding: '6px 10px', color: '#ef4444', cursor: 'pointer' }}>
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        </GlassPanel>
      ))}
      {bookings.length === 0 && <p style={{ color: 'rgba(255,255,255,0.3)', textAlign: 'center', padding: 40 }}>No bookings yet.</p>}
    </div>
  );
}