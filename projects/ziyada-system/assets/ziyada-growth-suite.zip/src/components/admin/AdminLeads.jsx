import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import GlassPanel from '../ziyada/GlassPanel';
import { Mail, Phone, Building, Tag, Trash2 } from 'lucide-react';

const statusColors = { new: '#8b5cf6', contacted: '#06b6d4', qualified: '#10b981', closed: '#f59e0b' };

export default function AdminLeads({ lang }) {
  const [leads, setLeads] = useState([]);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    base44.entities.Lead.list('-created_date', 100).then(setLeads);
  }, []);

  const updateStatus = async (id, status) => {
    await base44.entities.Lead.update(id, { status });
    setLeads(prev => prev.map(l => l.id === id ? { ...l, status } : l));
  };

  const deleteLead = async (id) => {
    await base44.entities.Lead.delete(id);
    setLeads(prev => prev.filter(l => l.id !== id));
  };

  const filtered = filter === 'all' ? leads : leads.filter(l => l.status === filter || l.type === filter);

  return (
    <div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {['all', 'new', 'contacted', 'qualified', 'closed', 'meeting', 'proposal', 'contact'].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{ padding: '6px 14px', borderRadius: 8, border: 'none', cursor: 'pointer', background: filter === f ? '#8b5cf6' : 'rgba(255,255,255,0.08)', color: '#fff', fontSize: '0.8rem', fontFamily: 'inherit' }}>{f}</button>
        ))}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {filtered.map(lead => (
          <GlassPanel key={lead.id} style={{ padding: '20px 24px' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8, flexWrap: 'wrap' }}>
                  <span style={{ fontWeight: 700, fontSize: '1rem' }}>{lead.name || 'N/A'}</span>
                  <span style={{ fontSize: '0.75rem', padding: '2px 10px', borderRadius: 20, background: `${statusColors[lead.status]}22`, color: statusColors[lead.status], border: `1px solid ${statusColors[lead.status]}44`, fontWeight: 700 }}>{lead.status}</span>
                  <span style={{ fontSize: '0.75rem', padding: '2px 10px', borderRadius: 20, background: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.5)' }}>{lead.type}</span>
                  {lead.language && <span style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.3)' }}>{lead.language.toUpperCase()}</span>}
                </div>
                <div style={{ display: 'flex', gap: 16, fontSize: '0.85rem', color: 'rgba(255,255,255,0.55)', flexWrap: 'wrap' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Mail size={13} />{lead.email}</span>
                  {lead.phone && <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Phone size={13} />{lead.phone}</span>}
                  {lead.company && <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Building size={13} />{lead.company}</span>}
                </div>
                {lead.challenge && <p style={{ marginTop: 8, fontSize: '0.85rem', color: 'rgba(255,255,255,0.4)', lineHeight: 1.6 }}>{lead.challenge}</p>}
                {lead.hubspot_id && <span style={{ fontSize: '0.75rem', color: '#06b6d4' }}>HubSpot ✓</span>}
              </div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                <select value={lead.status} onChange={e => updateStatus(lead.id, e.target.value)}
                  style={{ padding: '6px 10px', borderRadius: 8, background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)', color: '#fff', fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'inherit' }}>
                  {['new', 'contacted', 'qualified', 'closed'].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                <button onClick={() => deleteLead(lead.id)} style={{ background: 'rgba(239,68,68,0.15)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 8, padding: '6px 10px', color: '#ef4444', cursor: 'pointer' }}>
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          </GlassPanel>
        ))}
        {filtered.length === 0 && <p style={{ color: 'rgba(255,255,255,0.3)', textAlign: 'center', padding: 40 }}>No leads found.</p>}
      </div>
    </div>
  );
}