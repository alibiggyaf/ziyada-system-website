import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import GlassPanel from '../ziyada/GlassPanel';
import { Trash2, Edit, Eye, EyeOff } from 'lucide-react';

const inputStyle = { width: '100%', padding: '10px 14px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(139,92,246,0.3)', borderRadius: 8, color: '#fff', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box', fontFamily: 'inherit' };

const blank = { title_ar: '', title_en: '', client: '', industry: '', challenge_ar: '', challenge_en: '', solution_ar: '', solution_en: '', result_ar: '', result_en: '', cover_image: '', published: true, order: 0 };

export default function AdminCases({ lang }) {
  const [cases, setCases] = useState([]);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(blank);

  useEffect(() => {
    base44.entities.CaseStudy.list('order', 50).then(setCases);
  }, []);

  const set = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const save = async () => {
    if (editing) {
      const updated = await base44.entities.CaseStudy.update(editing, form);
      setCases(prev => prev.map(c => c.id === editing ? updated : c));
    } else {
      const created = await base44.entities.CaseStudy.create(form);
      setCases(prev => [...prev, created]);
    }
    setEditing(null);
    setForm(blank);
  };

  const startEdit = (c) => { setEditing(c.id); setForm({ ...blank, ...c }); };
  const del = async (id) => { await base44.entities.CaseStudy.delete(id); setCases(prev => prev.filter(c => c.id !== id)); };
  const togglePub = async (c) => { const u = await base44.entities.CaseStudy.update(c.id, { published: !c.published }); setCases(prev => prev.map(x => x.id === c.id ? u : x)); };

  return (
    <div>
      <GlassPanel style={{ padding: 28, marginBottom: 24 }}>
        <h3 style={{ fontWeight: 700, marginBottom: 20, color: '#8b5cf6' }}>{editing ? 'Edit Case' : 'New Case Study'}</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
          <input style={inputStyle} placeholder="Title (Arabic)" value={form.title_ar} onChange={e => set('title_ar', e.target.value)} />
          <input style={inputStyle} placeholder="Title (English)" value={form.title_en} onChange={e => set('title_en', e.target.value)} />
          <input style={inputStyle} placeholder="Client name" value={form.client} onChange={e => set('client', e.target.value)} />
          <input style={inputStyle} placeholder="Industry" value={form.industry} onChange={e => set('industry', e.target.value)} />
          <input style={inputStyle} placeholder="Cover Image URL" value={form.cover_image} onChange={e => set('cover_image', e.target.value)} />
          <input style={inputStyle} type="number" placeholder="Display order" value={form.order} onChange={e => set('order', parseInt(e.target.value) || 0)} />
          <textarea style={{ ...inputStyle, minHeight: 80 }} placeholder="Challenge (Arabic)" value={form.challenge_ar} onChange={e => set('challenge_ar', e.target.value)} />
          <textarea style={{ ...inputStyle, minHeight: 80 }} placeholder="Challenge (English)" value={form.challenge_en} onChange={e => set('challenge_en', e.target.value)} />
          <textarea style={{ ...inputStyle, minHeight: 80 }} placeholder="Solution (Arabic)" value={form.solution_ar} onChange={e => set('solution_ar', e.target.value)} />
          <textarea style={{ ...inputStyle, minHeight: 80 }} placeholder="Solution (English)" value={form.solution_en} onChange={e => set('solution_en', e.target.value)} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', color: 'rgba(255,255,255,0.7)' }}>
            <input type="checkbox" checked={form.published} onChange={e => set('published', e.target.checked)} style={{ accentColor: '#8b5cf6' }} />
            Published
          </label>
          <button onClick={save} style={{ padding: '10px 24px', background: 'linear-gradient(135deg, #8b5cf6, #06b6d4)', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}>
            {editing ? 'Update' : 'Create'}
          </button>
          {editing && <button onClick={() => { setEditing(null); setForm(blank); }} style={{ padding: '10px 16px', background: 'rgba(255,255,255,0.06)', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit' }}>Cancel</button>}
        </div>
      </GlassPanel>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {cases.map(c => (
          <GlassPanel key={c.id} style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
            <div style={{ flex: 1 }}>
              <span style={{ fontWeight: 700 }}>{lang === 'ar' ? c.title_ar : c.title_en}</span>
              {c.client && <span style={{ marginLeft: 10, fontSize: '0.8rem', color: 'rgba(255,255,255,0.4)' }}>{c.client}</span>}
              {c.industry && <span style={{ marginLeft: 8, fontSize: '0.75rem', color: '#06b6d4' }}>{c.industry}</span>}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={() => togglePub(c)} style={{ padding: '6px 10px', borderRadius: 8, border: 'none', cursor: 'pointer', background: c.published ? 'rgba(16,185,129,0.15)' : 'rgba(255,255,255,0.06)', color: c.published ? '#10b981' : 'rgba(255,255,255,0.4)' }}>
                {c.published ? <Eye size={14} /> : <EyeOff size={14} />}
              </button>
              <button onClick={() => startEdit(c)} style={{ padding: '6px 10px', borderRadius: 8, border: 'none', cursor: 'pointer', background: 'rgba(139,92,246,0.15)', color: '#8b5cf6' }}>
                <Edit size={14} />
              </button>
              <button onClick={() => del(c.id)} style={{ padding: '6px 10px', borderRadius: 8, border: 'none', cursor: 'pointer', background: 'rgba(239,68,68,0.15)', color: '#ef4444' }}>
                <Trash2 size={14} />
              </button>
            </div>
          </GlassPanel>
        ))}
      </div>
    </div>
  );
}