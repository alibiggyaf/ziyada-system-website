import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import GlassPanel from '../ziyada/GlassPanel';
import { PlusCircle, Trash2, Eye, EyeOff, Edit } from 'lucide-react';

const inputStyle = { width: '100%', padding: '10px 14px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(139,92,246,0.3)', borderRadius: 8, color: '#fff', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box', fontFamily: 'inherit' };

export default function AdminBlog({ lang }) {
  const [posts, setPosts] = useState([]);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ title_ar: '', title_en: '', slug: '', excerpt_ar: '', excerpt_en: '', content_ar: '', content_en: '', category: '', published: false, author: '', cover_image: '' });

  useEffect(() => {
    base44.entities.BlogPost.list('-created_date', 50).then(setPosts);
  }, []);

  const set = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const save = async () => {
    if (editing) {
      const updated = await base44.entities.BlogPost.update(editing, form);
      setPosts(prev => prev.map(p => p.id === editing ? updated : p));
    } else {
      const created = await base44.entities.BlogPost.create(form);
      setPosts(prev => [created, ...prev]);
    }
    setEditing(null);
    setForm({ title_ar: '', title_en: '', slug: '', excerpt_ar: '', excerpt_en: '', content_ar: '', content_en: '', category: '', published: false, author: '', cover_image: '' });
  };

  const startEdit = (post) => {
    setEditing(post.id);
    setForm({ title_ar: post.title_ar || '', title_en: post.title_en || '', slug: post.slug || '', excerpt_ar: post.excerpt_ar || '', excerpt_en: post.excerpt_en || '', content_ar: post.content_ar || '', content_en: post.content_en || '', category: post.category || '', published: post.published || false, author: post.author || '', cover_image: post.cover_image || '' });
  };

  const deletePost = async (id) => {
    await base44.entities.BlogPost.delete(id);
    setPosts(prev => prev.filter(p => p.id !== id));
  };

  const togglePublish = async (post) => {
    const updated = await base44.entities.BlogPost.update(post.id, { published: !post.published });
    setPosts(prev => prev.map(p => p.id === post.id ? updated : p));
  };

  return (
    <div>
      <GlassPanel style={{ padding: 28, marginBottom: 24 }}>
        <h3 style={{ fontWeight: 700, marginBottom: 20, color: '#8b5cf6' }}>{editing ? (lang === 'ar' ? 'تعديل مقال' : 'Edit Post') : (lang === 'ar' ? 'مقال جديد' : 'New Post')}</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
          <input style={inputStyle} placeholder="Title (Arabic)" value={form.title_ar} onChange={e => set('title_ar', e.target.value)} />
          <input style={inputStyle} placeholder="Title (English)" value={form.title_en} onChange={e => set('title_en', e.target.value)} />
          <input style={inputStyle} placeholder="Slug (e.g. my-article)" value={form.slug} onChange={e => set('slug', e.target.value)} />
          <input style={inputStyle} placeholder="Category" value={form.category} onChange={e => set('category', e.target.value)} />
          <input style={inputStyle} placeholder="Author" value={form.author} onChange={e => set('author', e.target.value)} />
          <input style={inputStyle} placeholder="Cover Image URL" value={form.cover_image} onChange={e => set('cover_image', e.target.value)} />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
          <textarea style={{ ...inputStyle, minHeight: 80, resize: 'vertical' }} placeholder="Excerpt (Arabic)" value={form.excerpt_ar} onChange={e => set('excerpt_ar', e.target.value)} />
          <textarea style={{ ...inputStyle, minHeight: 80, resize: 'vertical' }} placeholder="Excerpt (English)" value={form.excerpt_en} onChange={e => set('excerpt_en', e.target.value)} />
          <textarea style={{ ...inputStyle, minHeight: 160, resize: 'vertical' }} placeholder="Content (Arabic - Markdown)" value={form.content_ar} onChange={e => set('content_ar', e.target.value)} />
          <textarea style={{ ...inputStyle, minHeight: 160, resize: 'vertical' }} placeholder="Content (English - Markdown)" value={form.content_en} onChange={e => set('content_en', e.target.value)} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', color: 'rgba(255,255,255,0.7)' }}>
            <input type="checkbox" checked={form.published} onChange={e => set('published', e.target.checked)} style={{ accentColor: '#8b5cf6' }} />
            Published
          </label>
          <button onClick={save} style={{ padding: '10px 24px', background: 'linear-gradient(135deg, #8b5cf6, #06b6d4)', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}>
            {editing ? 'Update' : 'Create'}
          </button>
          {editing && <button onClick={() => setEditing(null)} style={{ padding: '10px 16px', background: 'rgba(255,255,255,0.06)', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit' }}>Cancel</button>}
        </div>
      </GlassPanel>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {posts.map(p => (
          <GlassPanel key={p.id} style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
            <div style={{ flex: 1 }}>
              <span style={{ fontWeight: 700 }}>{lang === 'ar' ? p.title_ar : p.title_en}</span>
              <span style={{ marginLeft: 10, fontSize: '0.75rem', color: 'rgba(255,255,255,0.4)' }}>{p.slug}</span>
              {p.category && <span style={{ marginLeft: 8, fontSize: '0.75rem', color: '#8b5cf6' }}>{p.category}</span>}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={() => togglePublish(p)} style={{ padding: '6px 10px', borderRadius: 8, border: 'none', cursor: 'pointer', background: p.published ? 'rgba(16,185,129,0.15)' : 'rgba(255,255,255,0.06)', color: p.published ? '#10b981' : 'rgba(255,255,255,0.4)' }}>
                {p.published ? <Eye size={14} /> : <EyeOff size={14} />}
              </button>
              <button onClick={() => startEdit(p)} style={{ padding: '6px 10px', borderRadius: 8, border: 'none', cursor: 'pointer', background: 'rgba(139,92,246,0.15)', color: '#8b5cf6' }}>
                <Edit size={14} />
              </button>
              <button onClick={() => deletePost(p.id)} style={{ padding: '6px 10px', borderRadius: 8, border: 'none', cursor: 'pointer', background: 'rgba(239,68,68,0.15)', color: '#ef4444' }}>
                <Trash2 size={14} />
              </button>
            </div>
          </GlassPanel>
        ))}
      </div>
    </div>
  );
}