import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { email, name, language } = await req.json();

    // Check if already subscribed
    const existing = await base44.asServiceRole.entities.Subscriber.filter({ email });
    if (existing && existing.length > 0) {
      return Response.json({ success: true, already_subscribed: true });
    }

    const subscriber = await base44.asServiceRole.entities.Subscriber.create({
      email, name: name || "", language: language || "ar", status: "active", welcome_email_sent: false
    });

    // Send welcome email
    const { accessToken: gmailToken } = await base44.asServiceRole.connectors.getConnection("gmail");
    const isAr = (language || "ar") === "ar";
    const subject = isAr ? "شكراً لاشتراكك مع زيادة للأنظمة" : "Thank you for subscribing to Ziyada Systems";
    const bodyText = isAr
      ? `مرحباً ${name || ""},\n\nشكراً لاشتراكك معنا في زيادة للأنظمة المتقدمة.\nسنبقيك على اطلاع بأحدث المقالات والأفكار.\n\nفريق زيادة`
      : `Hello ${name || ""},\n\nThank you for subscribing to Ziyada Systems.\nWe'll keep you updated with our latest articles and insights.\n\nThe Ziyada Team`;
    const raw = btoa(`To: ${email}\nSubject: ${subject}\nContent-Type: text/plain; charset=utf-8\n\n${bodyText}`).replace(/\+/g,'-').replace(/\//g,'_');
    const gmailRes = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
      method: "POST",
      headers: { "Authorization": `Bearer ${gmailToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({ raw })
    });
    if (gmailRes.ok) {
      await base44.asServiceRole.entities.Subscriber.update(subscriber.id, { welcome_email_sent: true });
    }

    return Response.json({ success: true, subscriber_id: subscriber.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});