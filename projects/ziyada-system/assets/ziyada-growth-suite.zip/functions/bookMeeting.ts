import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const ADMIN_EMAIL = "ziyadasystem@gmail.com";

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const { lead_name, lead_email, lead_phone, company, industry, company_size, challenge, booking_date, booking_time } = await req.json();

  let google_meet_link = null, google_calendar_event_id = null;

  // 1. Google Calendar event (non-blocking)
  try {
    const { accessToken: calToken } = await base44.asServiceRole.connectors.getConnection("googlecalendar");
    const startDateTime = `${booking_date}T${booking_time}:00`;
    const endHour = String(parseInt(booking_time.split(":")[0]) + 1).padStart(2, "0");
    const endDateTime = `${booking_date}T${endHour}:${booking_time.split(":")[1]}:00`;

    const calRes = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1&sendUpdates=all", {
      method: "POST",
      headers: { "Authorization": `Bearer ${calToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        summary: `Ziyada Strategy Session - ${lead_name}`,
        description: `Company: ${company}\nChallenge: ${challenge}`,
        start: { dateTime: startDateTime, timeZone: "Asia/Riyadh" },
        end: { dateTime: endDateTime, timeZone: "Asia/Riyadh" },
        attendees: [{ email: lead_email }, { email: ADMIN_EMAIL }],
        conferenceData: {
          createRequest: { requestId: `ziyada-${Date.now()}`, conferenceSolutionKey: { type: "hangoutsMeet" } }
        }
      })
    });
    if (calRes.ok) {
      const calData = await calRes.json();
      google_calendar_event_id = calData.id;
      google_meet_link = calData.conferenceData?.entryPoints?.find(e => e.entryPointType === "video")?.uri || null;
    }
  } catch (_) { /* calendar optional */ }

  // 2. Save booking to DB
  // Also save as Lead for CRM tracking
  try {
    await base44.asServiceRole.entities.Lead.create({
      name: lead_name, email: lead_email, phone: lead_phone || "",
      company: company || "", industry: industry || "", company_size: company_size || "",
      challenge: challenge || "", type: "meeting", status: "new", language: "ar"
    });
  } catch(_) { /* non-blocking */ }

  const booking = await base44.asServiceRole.entities.Booking.create({
    lead_name, lead_email, lead_phone: lead_phone || "",
    company: company || "", industry: industry || "", company_size: company_size || "",
    challenge: challenge || "", booking_date, booking_time,
    calendar_event_id: google_calendar_event_id, google_meet_link, status: "confirmed"
  });

  // 3. HubSpot (non-blocking)
  try {
    const { accessToken: hsToken } = await base44.asServiceRole.connectors.getConnection("hubspot");
    await fetch("https://api.hubapi.com/crm/v3/objects/contacts", {
      method: "POST",
      headers: { "Authorization": `Bearer ${hsToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        properties: {
          firstname: lead_name?.split(" ")[0] || lead_name,
          lastname: lead_name?.split(" ").slice(1).join(" ") || "",
          email: lead_email, phone: lead_phone || "", company: company || "",
          hs_lead_status: "IN_PROGRESS",
          message: `Booked meeting for ${booking_date} at ${booking_time}. Challenge: ${challenge}`
        }
      })
    });
  } catch (_) { /* hubspot optional */ }

  // 4. Send confirmation email (non-blocking)
  try {
    const { accessToken: gmailToken } = await base44.asServiceRole.connectors.getConnection("gmail");
    const meetInfo = google_meet_link ? `\n\nGoogle Meet: ${google_meet_link}` : "";
    const confirmBody = `Dear ${lead_name},\n\nYour strategy session with Ziyada Systems is confirmed!\n\nDate: ${booking_date}\nTime: ${booking_time}${meetInfo}\n\nZiyada Systems\n---\n\nعزيزي ${lead_name}،\nتم تأكيد جلستك الاستراتيجية مع زيادة للأنظمة!\n\nالتاريخ: ${booking_date}\nالوقت: ${booking_time}${meetInfo}\n\nفريق زيادة للأنظمة`;
    const rawConfirm = btoa(unescape(encodeURIComponent(`To: ${lead_email}\nSubject: Meeting Confirmed - Ziyada Systems\nContent-Type: text/plain; charset=utf-8\n\n${confirmBody}`))).replace(/\+/g,'-').replace(/\//g,'_');
    await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
      method: "POST", headers: { "Authorization": `Bearer ${gmailToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({ raw: rawConfirm })
    });
    // Admin notify
    const adminBody = `New booking!\nName: ${lead_name}\nEmail: ${lead_email}\nPhone: ${lead_phone}\nCompany: ${company}\nDate: ${booking_date} at ${booking_time}\nChallenge: ${challenge}${meetInfo}`;
    const rawAdmin = btoa(unescape(encodeURIComponent(`To: ${ADMIN_EMAIL}\nSubject: New Booking: ${lead_name} - ${booking_date}\nContent-Type: text/plain; charset=utf-8\n\n${adminBody}`))).replace(/\+/g,'-').replace(/\//g,'_');
    await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
      method: "POST", headers: { "Authorization": `Bearer ${gmailToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({ raw: rawAdmin })
    });
  } catch (_) { /* email optional */ }

  return Response.json({ success: true, booking_id: booking.id, google_meet_link, booking_date, booking_time });
});