import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { name, email, phone, company, industry, company_size, challenge, booking_date, booking_time, language } = body;

    // Create Google Calendar event with Meet link
    const { accessToken: calToken } = await base44.asServiceRole.connectors.getConnection('googlecalendar');

    const startDateTime = new Date(`${booking_date}T${booking_time}:00`);
    const endDateTime = new Date(startDateTime.getTime() + 60 * 60 * 1000); // 1 hour

    const calEvent = {
      summary: `استشارة زيادة - ${name} | Ziyada Consultation`,
      description: `Client: ${name}\nCompany: ${company || 'N/A'}\nChallenge: ${challenge || 'N/A'}`,
      start: { dateTime: startDateTime.toISOString(), timeZone: 'Asia/Riyadh' },
      end: { dateTime: endDateTime.toISOString(), timeZone: 'Asia/Riyadh' },
      attendees: [{ email }],
      conferenceData: { createRequest: { requestId: `ziyada-${Date.now()}`, conferenceSolutionKey: { type: 'hangoutsMeet' } } }
    };

    const calRes = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1&sendUpdates=all', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${calToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(calEvent)
    });
    const calData = await calRes.json();
    const meetLink = calData.conferenceData?.entryPoints?.find(e => e.entryPointType === 'video')?.uri || '';
    const eventId = calData.id || '';

    // Save booking to DB
    const booking = await base44.asServiceRole.entities.Booking.create({
      name, email, phone, company, industry, company_size, challenge,
      booking_date, booking_time, google_meet_link: meetLink,
      calendar_event_id: eventId, status: 'confirmed', language: language || 'ar'
    });

    // Push to HubSpot as deal
    const { accessToken: hsToken } = await base44.asServiceRole.connectors.getConnection('hubspot');

    const searchRes = await fetch('https://api.hubapi.com/crm/v3/objects/contacts/search', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${hsToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ filterGroups: [{ filters: [{ propertyName: 'email', operator: 'EQ', value: email }] }] })
    });
    const searchData = await searchRes.json();
    let contactId;
    if (searchData.total > 0) {
      contactId = searchData.results[0].id;
    } else {
      const cr = await fetch('https://api.hubapi.com/crm/v3/objects/contacts', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${hsToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ properties: { email, firstname: name?.split(' ')[0] || name, lastname: name?.split(' ').slice(1).join(' ') || '', phone: phone || '', company: company || '' } })
      });
      const cd = await cr.json();
      contactId = cd.id;
    }

    const dealRes = await fetch('https://api.hubapi.com/crm/v3/objects/deals', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${hsToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ properties: { dealname: `Consultation - ${name}`, dealstage: 'appointmentscheduled', pipeline: 'default', closedate: booking_date } })
    });
    const dealData = await dealRes.json();
    if (dealData.id && contactId) {
      await fetch(`https://api.hubapi.com/crm/v3/objects/deals/${dealData.id}/associations/contacts/${contactId}/deal_to_contact`, {
        method: 'PUT', headers: { 'Authorization': `Bearer ${hsToken}` }
      });
      await base44.asServiceRole.entities.Booking.update(booking.id, { hubspot_deal_id: dealData.id });
    }

    // Send confirmation email via Gmail
    const { accessToken: gmailToken } = await base44.asServiceRole.connectors.getConnection('gmail');
    const isAr = language === 'ar';
    const subject = isAr ? 'تأكيد حجز جلستك الاستراتيجية - زيادة للأنظمة' : 'Your Strategy Session Confirmed - Ziyada Systems';
    const emailBody = isAr
      ? `<div dir="rtl" style="font-family: Arial; padding: 30px; background: #0a0a0a; color: #fff;">
          <h2 style="color: #8b5cf6;">تم تأكيد موعدك، ${name}!</h2>
          <p>نتطلع لمحادثتنا معك.</p>
          <div style="background: #1a1a2e; border: 1px solid #8b5cf6; border-radius: 12px; padding: 20px; margin: 20px 0;">
            <p><strong>التاريخ:</strong> ${booking_date}</p>
            <p><strong>الوقت:</strong> ${booking_time}</p>
            <p><strong>رابط Google Meet:</strong> <a href="${meetLink}" style="color: #8b5cf6;">${meetLink || 'سيُرسل قريباً'}</a></p>
          </div>
          <hr style="border-color: #333;"/>
          <p style="font-size: 12px; color: #888;">© 2026 Ziyada Systems | زيادة للأنظمة المتقدمة</p>
        </div>`
      : `<div style="font-family: Arial; padding: 30px; background: #0a0a0a; color: #fff;">
          <h2 style="color: #8b5cf6;">Session Confirmed, ${name}!</h2>
          <p>We look forward to speaking with you.</p>
          <div style="background: #1a1a2e; border: 1px solid #8b5cf6; border-radius: 12px; padding: 20px; margin: 20px 0;">
            <p><strong>Date:</strong> ${booking_date}</p>
            <p><strong>Time:</strong> ${booking_time}</p>
            <p><strong>Google Meet:</strong> <a href="${meetLink}" style="color: #8b5cf6;">${meetLink || 'Coming soon'}</a></p>
          </div>
          <hr style="border-color: #333;"/>
          <p style="font-size: 12px; color: #888;">© 2026 Ziyada Systems</p>
        </div>`;

    const emailMsg = [
      `To: ${email}`, 'Content-Type: text/html; charset=utf-8', 'MIME-Version: 1.0', `Subject: ${subject}`, '', emailBody
    ].join('\n');
    const encoded = btoa(unescape(encodeURIComponent(emailMsg))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${gmailToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ raw: encoded })
    });

    return Response.json({ success: true, booking_id: booking.id, meet_link: meetLink });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});