/**
 * BACKEND FUNCTIONS GUIDE — Ziyada B2B Platform
 * 
 * This is a reference file documenting all backend functions, integrations, and configurations.
 * Copy this content to a .md file in your exported project.
 * 
 * Location: functions/
 * 
 * ============================================================================
 * BACKEND FUNCTIONS INVENTORY
 * ============================================================================
 */

/*
FUNCTION 1: bookMeeting
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Purpose: Create Google Calendar events and save booking records

Triggers: Form submission from /BookMeeting page

Integrations:
  - Google Calendar API (OAuth)
  - HubSpot Deals API
  - Base44 Database (Booking entity)

Input:
{
  "lead_name": "John Doe",
  "lead_email": "john@example.com",
  "lead_phone": "+966501234567",
  "company": "Acme Corp",
  "industry": "Technology",
  "company_size": "50-200",
  "challenge": "Streamline sales processes",
  "booking_date": "2026-03-20",
  "booking_time": "14:00"
}

Output:
{
  "success": true,
  "booking_id": "uuid-string",
  "google_meet_link": "https://meet.google.com/...",
  "calendar_event_id": "event-id-string",
  "hubspot_deal_id": "deal-id-string"
}

Workflow:
1. Validate email & date (must be future)
2. Create Google Calendar event with video conferencing (Google Meet)
3. Extract Google Meet link from event
4. Save booking to Base44 Booking entity
5. Create HubSpot Deal (sales opportunity)
6. Send confirmation email to user
7. Send internal notification email
8. Return success response with meeting details
*/

/*
FUNCTION 2: submitLead
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Purpose: Save contact form submissions and sync to HubSpot CRM

Triggers: Form submission from /Contact, /RequestProposal, /BookMeeting

Input:
{
  "name": "Sarah Smith",
  "email": "sarah@company.com",
  "phone": "+966501234567",
  "company": "Tech Solutions Ltd",
  "industry": "Software",
  "challenge": "Need automation for manual processes",
  "services": ["automation", "crm"],
  "budget": "10-25k",
  "timeline": "1-3 months",
  "type": "proposal",
  "language": "ar"
}

Output:
{
  "success": true,
  "lead_id": "uuid-string",
  "hubspot_contact_id": "contact-id-string",
  "saved_at": "2026-03-13T10:30:00Z"
}

Workflow:
1. Validate email format
2. Check if contact already exists in HubSpot
3. Create or update contact in HubSpot with custom properties
4. Save lead record to Base44 Lead entity
5. Send internal notification to sales team
6. Return confirmation
*/

/*
FUNCTION 3: getAvailableSlots
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Purpose: Fetch available meeting time slots from Google Calendar

Triggers: User selects a date on /BookMeeting calendar picker

Input:
{
  "date": "2026-03-20"
}

Output:
{
  "date": "2026-03-20",
  "available_slots": [
    "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "14:00", "14:30", "15:00"
  ],
  "timezone": "Asia/Riyadh"
}

Workflow:
1. Query Google Calendar for the specified date
2. Get all booked events for that day
3. Calculate available 30-minute slots (business hours: 9 AM - 5 PM)
4. Apply 1-hour buffer between meetings
5. Return available slots to frontend for user selection
*/

/*
FUNCTION 4: subscribeEmail
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Purpose: Newsletter subscription handler

Triggers: Newsletter form in Footer component

Input:
{
  "email": "subscriber@example.com",
  "language": "ar"
}

Output:
{
  "success": true,
  "message": "Subscribed successfully"
}

Workflow:
1. Validate email format
2. Check if already subscribed
3. Add to subscriber database
4. Send welcome email
5. Return success
*/

/*
FUNCTION 5: submitBooking
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Purpose: Finalize booking after user confirms

Triggers: User submits final booking confirmation

Input:
{
  "lead_name": "John Doe",
  "lead_email": "john@example.com",
  "booking_date": "2026-03-20",
  "booking_time": "14:00",
  "company": "Acme Corp"
}

Output:
{
  "success": true,
  "booking_id": "uuid-string",
  "google_meet_link": "https://meet.google.com/...",
  "confirmation_email_sent": true
}

Workflow:
1. Create Google Calendar event with Meet link
2. Save booking to database
3. Create/update HubSpot contact & deal
4. Send confirmation email to user
5. Send internal notification
6. Return confirmation details
*/

/*
FUNCTION 6: n8nWebhook
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Purpose: Receive and process webhooks from n8n automation workflows

Triggers: n8n workflow sends POST request

Input:
{
  "workflow_id": "string",
  "action": "create_lead|update_contact|send_email",
  "data": { /* workflow-specific data */ }
}

Output:
{
  "success": true,
  "processed": true,
  "result": { /* workflow result */ }
}

Workflow:
1. Validate webhook signature (if configured)
2. Parse workflow data
3. Execute appropriate action (create/update/send)
4. Return response to n8n
*/

/*
============================================================================
INTEGRATION DETAILS
============================================================================

HUBSPOT INTEGRATION
───────────────────
Authorization: OAuth (already configured in Base44)
Access Token: Retrieved via base44.asServiceRole.connectors.getConnection("hubspot")

Key Objects:
  • Contacts — Company representatives (email, phone, company, industry)
  • Deals — Sales opportunities (name, stage, value, service_interested)

Pipeline Stages:
  1. Contacted (initial contact from form)
  2. Qualified (assessment completed)
  3. Proposal Sent
  4. Negotiation
  5. Closed Won / Closed Lost

Usage Example:
────────────────
const { accessToken } = await base44.asServiceRole.connectors.getConnection("hubspot");

// Create contact
const contact = await fetch('https://api.hubapi.com/crm/v3/objects/contacts', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${accessToken}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    properties: {
      firstname: 'John',
      lastname: 'Doe',
      email: 'john@example.com',
      phone: '+966501234567',
      company: 'Acme Corp',
      lifecyclestage: 'lead'
    }
  })
}).then(r => r.json());

// Create deal (sales opportunity)
const deal = await fetch('https://api.hubapi.com/crm/v3/objects/deals', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${accessToken}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    properties: {
      dealname: 'Acme Corp - Automation Services',
      dealstage: 'qualificationphase',
      pipeline: 'default',
      closedate: Date.now() + (90 * 24 * 60 * 60 * 1000), // 90 days
      services_interested: ['automation', 'crm']
    }
  })
}).then(r => r.json());

────────────────


GOOGLE CALENDAR INTEGRATION
────────────────────────────
Authorization: OAuth (already configured in Base44)
Access Token: Retrieved via base44.asServiceRole.connectors.getConnection("googlecalendar")
Timezone: Asia/Riyadh

Usage Example:
────────────────
const { accessToken } = await base44.asServiceRole.connectors.getConnection("googlecalendar");

// List events for a specific date
const events = await fetch(
  'https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=2026-03-20T00:00:00&timeMax=2026-03-20T23:59:59',
  {
    headers: { 'Authorization': `Bearer ${accessToken}` }
  }
).then(r => r.json());

// Create event with Google Meet
const event = await fetch(
  'https://www.googleapis.com/calendar/v3/calendars/primary/events',
  {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      summary: 'Strategy Session with Ziyada Systems',
      description: 'Discussion about automation opportunities',
      start: {
        dateTime: '2026-03-20T14:00:00',
        timeZone: 'Asia/Riyadh'
      },
      end: {
        dateTime: '2026-03-20T15:00:00',
        timeZone: 'Asia/Riyadh'
      },
      conferenceData: {
        createRequest: {
          requestId: 'unique-id-' + Date.now(),
          conferenceSolutionKey: { type: 'hangoutsMeet' }
        }
      },
      attendees: [
        { email: 'john@example.com' }
      ]
    })
  }
).then(r => r.json());

const meetLink = event.conferenceData.entryPoints[0].uri;

────────────────


GMAIL INTEGRATION
──────────────────
Authorization: OAuth (already configured in Base44)
Access Token: Retrieved via base44.asServiceRole.connectors.getConnection("gmail")

Usage Example:
────────────────
const { accessToken } = await base44.asServiceRole.connectors.getConnection("gmail");

const sendEmail = async (to, subject, body) => {
  const message = btoa(`To: ${to}\nSubject: ${subject}\n\n${body}`);
  
  const res = await fetch(
    'https://www.googleapis.com/gmail/v1/users/me/messages/send',
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ raw: message })
    }
  );
  
  return res.json();
};

await sendEmail(
  'john@example.com',
  'Your Meeting Confirmation',
  'Your meeting is scheduled for tomorrow at 2 PM. Join: https://meet.google.com/...'
);

────────────────


BASE44 DATABASE INTEGRATION
─────────────────────────────
SDK Setup:
────────────
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const user = await base44.auth.me();
  
  if (!user) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }
  
  // Use base44 to interact with entities
});

Entity Operations:
────────────────
// Create
const booking = await base44.entities.Booking.create({
  lead_name: 'John',
  lead_email: 'john@example.com',
  booking_date: '2026-03-20',
  booking_time: '14:00'
});

// Read
const bookings = await base44.entities.Booking.list();
const filtered = await base44.entities.Booking.filter({ lead_email: 'john@example.com' });

// Update
await base44.entities.Booking.update(booking.id, {
  status: 'confirmed'
});

// Delete
await base44.entities.Booking.delete(booking.id);

════════════════════════════════════════════════════════════════════════════════════
END OF GUIDE
════════════════════════════════════════════════════════════════════════════════════

SAVE THIS FILE AS: BACKEND_FUNCTIONS_GUIDE.md in your exported project
*/