import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// n8n webhook endpoint — call this from your n8n workflow to push blog posts
// Method: POST
// Payload: { secret: "ziyada-n8n-2026", post: { title_ar, title_en, excerpt_ar, excerpt_en, content_ar, content_en, tags, author, cover_image } }

const N8N_SECRET = "ziyada-n8n-2026";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    if (body.secret !== N8N_SECRET) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const post = body.post;
    const slug = post.slug || post.title_en?.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "") + "-" + Date.now();

    const created = await base44.asServiceRole.entities.BlogPost.create({
      title_ar: post.title_ar,
      title_en: post.title_en,
      slug,
      excerpt_ar: post.excerpt_ar || "",
      excerpt_en: post.excerpt_en || "",
      content_ar: post.content_ar || "",
      content_en: post.content_en || "",
      cover_image: post.cover_image || "",
      tags: post.tags || [],
      author: post.author || "Ziyada Systems",
      status: post.status || "published",
      published_date: new Date().toISOString().split("T")[0]
    });

    return Response.json({ success: true, post_id: created.id, slug });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});