import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const ADMIN_EMAIL = "ziyadasystem@gmail.com";

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const body = await req.json();
  const { name, email, phone, company, industry, company_size, challenge, source, budget, timeline, services_requested, language } = body;

  // Save lead
  const lead = await base44.asServiceRole.entities.Lead.create({
    name, email, phone: phone || "", company: company || "", industry: industry || "",
    company_size: company_size || "", challenge: challenge || "",
    type: source || "contact", budget: budget || "", timeline: timeline || "",
    services: services_requested || [], status: "new", language: language || "ar"
  });

  // HubSpot (non-blocking)
  try {
    const { accessToken } = await base44.asServiceRole.connectors.getConnection("hubspot");
    const hsRes = await fetch("https://api.hubapi.com/crm/v3/objects/contacts", {
      method: "POST",
      headers: { "Authorization": `Bearer ${accessToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        properties: {
          firstname: name?.split(" ")[0] || name,
          lastname: name?.split(" ").slice(1).join(" ") || "",
          email, phone: phone || "", company: company || "",
          jobtitle: industry || "", hs_lead_status: "NEW", message: challenge || ""
        }
      })
    });
    if (hsRes.ok) {
      const hsData = await hsRes.json();
      await base44.asServiceRole.entities.Lead.update(lead.id, { hubspot_id: hsData.id });
    }
  } catch (_) { /* hubspot optional */ }

  // Admin email (non-blocking)
  try {
    const { accessToken: gmailToken } = await base44.asServiceRole.connectors.getConnection("gmail");
    const emailBody = `New lead from Ziyada website!\n\nName: ${name}\nEmail: ${email}\nPhone: ${phone}\nCompany: ${company}\nSource: ${source}\nChallenge: ${challenge}\nBudget: ${budget}\nTimeline: ${timeline}`;
    const raw = btoa(unescape(encodeURIComponent(`To: ${ADMIN_EMAIL}\nSubject: New Lead: ${name}\nContent-Type: text/plain; charset=utf-8\n\n${emailBody}`))).replace(/\+/g,'-').replace(/\//g,'_');
    await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
      method: "POST", headers: { "Authorization": `Bearer ${gmailToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({ raw })
    });
  } catch (_) { /* email optional */ }

  return Response.json({ success: true, lead_id: lead.id });
});