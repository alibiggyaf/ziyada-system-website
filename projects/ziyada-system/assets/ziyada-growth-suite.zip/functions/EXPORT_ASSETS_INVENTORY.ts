/**
 * ASSETS & COMPONENTS INVENTORY — Ziyada B2B Platform
 * 
 * This is a reference file documenting all frontend components, assets, and design system.
 * Copy this content to a .md file in your exported project.
 * 
 * ============================================================================
 * COMPLETE COMPONENT STRUCTURE
 * ============================================================================
 */

/*
LAYOUT COMPONENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Layout.jsx (Main Wrapper)
   Purpose: Wraps all pages with header, footer, language/theme toggle
   Exports: Language & theme context
   Usage: <ZiyadaLayout><Outlet /></ZiyadaLayout>

2. Navbar.jsx (Navigation Header)
   Features:
     • Fixed header with gradient logo
     • Nav links with active state
     • Language toggle (AR/EN)
     • Theme toggle (Dark/Light)
     • Mobile hamburger menu
     • CTA button (Book Consultation)
   Props: lang, toggleLang, theme, toggleTheme, isRTL

3. Footer.jsx (Footer Component)
   Features:
     • Quick links navigation
     • Newsletter subscription
     • Legal links (Privacy, Terms)
     • Brand info & contact
   Props: lang

4. ThreeBackground.jsx (3D Animated Background)
   Purpose: Three.js 3D visualization with animated particles
   Features:
     • GPU accelerated
     • Particle system
     • Dark theme optimized
     • Auto-plays on scroll
   Location: Fixed to viewport, behind all content
   Performance: ~2-3MB bundled

════════════════════════════════════════════════════════════════════════════════════

VISUAL COMPONENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. GlassPanel.jsx (Glassmorphism Cards)
   Purpose: Reusable frosted glass effect component
   Features:
     • Backdrop blur effect
     • Border glow animation on hover
     • Light mode support
     • CSS variables driven
   CSS Class: .glass-panel
   Animations: borderBeam, shine
   Usage: <GlassPanel><content></GlassPanel>

2. AnimatedServiceCard.jsx (Service Card)
   Purpose: Service showcase card with scroll animations
   Features:
     • Scroll-triggered fade-in + slide-up
     • Rainbow gradient border on hover
     • Icon with hover glow
     • Title, description, CTA
   Props: svc, index, isRTL, Arrow, theme
   Animation: Intersection Observer for scroll trigger
   Performance: memo-wrapped for optimization

3. ServiceDetailPage.jsx (Service Detail Template)
   Purpose: Reusable layout for all 7 service pages
   Sections:
     1. Hero (icon, tag, title, description)
     2. Scope & Features (side-by-side grid)
     3. Expected Results (highlighted badges)
     4. Case Study (5W: Who/What/When/Where/Why)
     5. CTA Box (Book Free Session / Request Proposal)
   Props: data (icon, title, desc, scope, features, results, case), lang
   Reused by: ServiceAutomation, ServiceCRM, ServiceLeadGen, ServiceMarketing,
              ServiceWebDev, ServiceSEO, ServiceSocial

════════════════════════════════════════════════════════════════════════════════════

INTERACTIVE COMPONENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. ROICalculator.jsx (ROI ESTIMATION ENGINE) ★ CORE COMPONENT
   Purpose: Multi-step ROI calculator for each service
   Services Supported:
     • ops_automation (Automation)
     • sales_crm (CRM & Sales)
     • marketing (Digital Marketing)
     • web_dev (Web Development)

   Calculation Logic:
   ────────────────
   
   AUTOMATION SERVICE:
   • Inputs: team_size, hours_wasted, hourly_cost, errors_monthly, error_fix_hrs
   • Outputs: annual_hours_saved, cost_saved, rework_reduction, total, ROI_x
   • Formula:
     - monthly_hours_saved = team_size × hours_wasted × 22 days × 0.70 automation
     - annual_hours_saved = monthly_hours_saved × 12
     - cost_saved = annual_hours_saved × hourly_cost
     - rework_saved = errors_monthly × error_fix_hrs × hourly_cost × 12 × 0.80
     - total = cost_saved + rework_saved
     - ROI_x = total / (team_size × 1500 × 12)

   SALES CRM SERVICE:
   • Inputs: monthly_leads, conversion_rate, avg_deal, lost_leads_pct, sales_team_size
   • Outputs: extra_from_recovery, extra_from_cvr, sales_time_saved, total, ROI_x
   • Formula:
     - recovered_leads = monthly_leads × (lost_leads_pct/100) × 0.40 recovery rate
     - new_conversion = min(conversion_rate × 1.35, 100%)
     - extra_from_recovery = recovered_leads × (conversion_rate/100) × avg_deal × 12
     - extra_from_cvr = monthly_leads × ((new_conversion - conversion_rate)/100) × avg_deal × 12
     - sales_time_saved = sales_team_size × 40 hours × 12 × hourly_cost
     - total = extra_from_recovery + extra_from_cvr + sales_time_saved
     - ROI_x = total / (sales_team_size × 1500 × 12)

   MARKETING SERVICE:
   • Inputs: monthly_budget, current_roas, monthly_visitors, cvr, avg_deal
   • Outputs: roas_gain, cvr_gain, total, ROI_x
   • Formula:
     - new_roas = current_roas × 2.2
     - roas_gain = (new_roas - current_roas) × monthly_budget × 12
     - new_cvr = min(cvr × 1.5, 100%)
     - extra_clients = monthly_visitors × ((new_cvr - cvr)/100) × 12
     - cvr_gain = extra_clients × avg_deal
     - total = roas_gain + cvr_gain
     - ROI_x = total / (monthly_budget × 12 × 0.15)

   WEB DEVELOPMENT SERVICE:
   • Inputs: monthly_visitors, current_cvr, avg_deal, sales_lost_pct
   • Outputs: cvr_gain, recovered, total, ROI_x
   • Formula:
     - new_cvr = min(current_cvr × 2.5, 100%)
     - extra_clients = monthly_visitors × ((new_cvr - current_cvr)/100) × 12
     - cvr_gain = extra_clients × avg_deal
     - recovered = monthly_visitors × (sales_lost_pct/100) × (current_cvr/100) × 0.30 × avg_deal × 12
     - total = cvr_gain + recovered
     - ROI_x = total / 25000

   Features:
     • Step 1: Service selection (4 options)
     • Step 2: Input sliders (service-specific)
     • Step 3: Results display with ROI multiple (x)
     • Light mode compatible
     • RTL support (Arabic)

   Props: lang ("ar" or "en")
   Usage: <ROICalculator lang={lang} />

════════════════════════════════════════════════════════════════════════════════════

BRAND ICONS (17 CUSTOM SVG ICONS)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Location: components/ziyada/BrandIcons.jsx

All icons use consistent styling:
  • Stroke-based design (not filled)
  • Stroke width: 2
  • Line cap: round
  • Joinable lines: round
  • Color: currentColor (inherits from parent)

Icon List:
───────────

1. IconZap — Lightning bolt (Automation/Power)
2. IconTarget — Bullseye (CRM/Precision)
3. IconRocket — Rocket ship (Lead Gen/Growth)
4. IconMegaphone — Speaker (Marketing)
5. IconGlobe — World globe (Web Dev)
6. IconBarChart — Bar chart (SEO/Analytics)
7. IconShare — Network nodes (Social Media)
8. IconCrosshair — Crosshair (Precision)
9. IconHandshake — Handshake (Partnership)
10. IconTrendingUp — Upward trend (Results/Success)
11. IconRefresh — Circular arrows (Continuous improvement)
12. IconClockAlert — Clock with alert (Time waste)
13. IconTrendingDown — Downward trend (Lost sales/Decline)
14. IconEyeOff — Eye with slash (No visibility)
15. IconUnlink — Broken link (Disconnected systems)
16. IconCalculator — Calculator (ROI Calculator)
17. Plus Lucide React icons (50+ available from lucide-react library)

Usage Example:
──────────────
import { IconZap, IconTarget, IconRocket } from "@/components/ziyada/BrandIcons";

<IconZap size={24} />
<IconTarget size={32} style={{ color: '#3b82f6' }} />

════════════════════════════════════════════════════════════════════════════════════

UTILITY HOOKS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. useScrollReveal.js
   Purpose: Scroll-triggered fade-in + slide-up animations
   Hook Signature: const { ref, style } = useScrollReveal()
   Uses: Intersection Observer API
   CSS Properties: opacity, transform (translateY)
   Animation Duration: 0.7s
   Example:
   ─────────
   const { ref, style } = useScrollReveal();
   return <div ref={ref} style={style}>Animated content</div>;

2. useTranslation.js
   Purpose: Language/translation helper hook
   Hook Signature: const { lang, t } = useTranslation()
   Returns: Current language code, text dictionary
   Example:
   ─────────
   const { lang, t } = useTranslation();
   return <h1>{lang === 'ar' ? 'مرحبا' : 'Hello'}</h1>;

3. Analytics.jsx
   Purpose: Event tracking for Base44 analytics
   Integrations: Base44 Analytics, HubSpot tracking
   Events Tracked: Page views, button clicks, form submissions, conversions

════════════════════════════════════════════════════════════════════════════════════

ADMIN COMPONENTS (5 FILES)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Location: components/admin/

1. AdminDashboard.jsx
   Purpose: Main admin control panel
   Features: Tab navigation between leads, bookings, blog, case studies

2. AdminLeads.jsx
   Purpose: Lead/contact management
   Features: List, create, edit, delete leads; view HubSpot sync status

3. AdminBookings.jsx
   Purpose: Booking management
   Features: View scheduled meetings, cancel bookings

4. AdminBlog.jsx
   Purpose: Blog post management
   Features: Create, edit, publish/unpublish blog posts

5. AdminCases.jsx
   Purpose: Case study management
   Features: Create, edit, delete success stories

════════════════════════════════════════════════════════════════════════════════════

SHADCN/UI COMPONENTS (50+)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Location: components/ui/

Pre-installed components ready to use:
  • Button, Input, Textarea, Select
  • Card, Dialog, Drawer, Sheet
  • Tabs, Accordion, Collapse
  • Toast, Dropdown Menu, Popover
  • Badge, Alert, Separator
  • And 30+ more...

Import Style:
──────────────
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";

════════════════════════════════════════════════════════════════════════════════════

GLOBAL STYLING SYSTEM
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

File: globals.css (~800 lines)

CSS Variables (Dark Mode - Default):
────────────────────────────────────
--bg-deep: #0f172a;              // Page background
--bg-glass: rgba(15, 23, 42, 0.6);  // Glassmorphic background
--bg-card: rgba(30, 41, 59, 0.4);   // Card background
--text-primary: #ffffff;            // Main text
--text-secondary: #e2e8f0;          // Secondary text
--accent-primary: #3b82f6;          // Primary accent (blue)
--accent-glow: #8b5cf6;             // Secondary accent (purple)
--border-glass: rgba(255, 255, 255, 0.1);  // Glass borders
--shadow-glass: 0 8px 32px 0 rgba(0, 0, 0, 0.37);  // Glass shadow
--radius-card: 16px;                // Card border radius
--header-height: 80px;              // Header height

CSS Variables (Light Mode - Togglable):
───────────────────────────────────────
Automatically overridden when .light-mode class is applied to body

Key Animations (@keyframes):
─────────────────────────────
• shine — Shimmer effect on gradients
• borderBeam — Neon border glow animation
• pulse — Fade pulse effect
• cursorPulse — Custom cursor glow
• revealUp — Scroll reveal fade + slide
• ctaBeamSpin — CTA button glow spin
• heroBadgePop — Hero badges entrance
• heroTitleReveal — Hero title entrance
• statPop — Stats counter pop-in
• cardBorderSpin — Service card border spin
• ctaGlowPulse — CTA section glow pulse

Responsive Breakpoints:
───────────────────────
@media (max-width: 900px)  — Tablet size
@media (max-width: 768px)  — Mobile size

════════════════════════════════════════════════════════════════════════════════════

PAGES STRUCTURE (20 PAGES)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MAIN PAGES:
───────────
1. Home.jsx — Landing page with hero, stats, service grid
2. Services.jsx — All 7 services overview
3. About.jsx — Company info, mission, values
4. Why.jsx — Value proposition, problem-solution
5. Cases.jsx — Success stories grid
6. Blog.jsx — Blog post listing
7. BlogPost.jsx — Individual blog post
8. FAQ.jsx — Frequently asked questions

SERVICE DETAIL PAGES (7):
─────────────────────────
9. ServiceAutomation.jsx — Business Automation details + ROI Calculator
10. ServiceCRM.jsx — CRM & Sales details + ROI Calculator
11. ServiceLeadGen.jsx — B2B Lead Gen details + ROI Calculator
12. ServiceMarketing.jsx — Digital Marketing details + ROI Calculator
13. ServiceWebDev.jsx — Web Development details + ROI Calculator
14. ServiceSEO.jsx — SEO & SEM details + ROI Calculator
15. ServiceSocial.jsx — Social Media Mgmt details + ROI Calculator

CONVERSION PAGES:
──────────────────
16. BookMeeting.jsx — Calendar booking form (Google Calendar integrated)
17. RequestProposal.jsx — Proposal request form
18. Contact.jsx — General contact form

UTILITY PAGES:
──────────────
19. ThankYou.jsx — Confirmation page after submission
20. Privacy.jsx — Privacy policy
21. Terms.jsx — Terms of use
22. AdminDashboard.jsx — Admin control panel

════════════════════════════════════════════════════════════════════════════════════

ASSETS EXPORT CHECKLIST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

When exporting, ensure you have:

Components to Export:
  ☐ components/ziyada/Layout.jsx
  ☐ components/ziyada/Navbar.jsx
  ☐ components/ziyada/Footer.jsx
  ☐ components/ziyada/ThreeBackground.jsx
  ☐ components/ziyada/BrandIcons.jsx (ALL 17 ICONS)
  ☐ components/ziyada/ROICalculator.jsx (CALCULATION ENGINE)
  ☐ components/ziyada/ServiceDetailPage.jsx
  ☐ components/ziyada/AnimatedServiceCard.jsx
  ☐ components/ziyada/GlassPanel.jsx
  ☐ components/ziyada/useScrollReveal.js
  ☐ components/ziyada/useTranslation.js
  ☐ components/ziyada/Analytics.jsx
  ☐ components/ziyada/blogContent.js
  ☐ components/admin/ (5 admin components)
  ☐ components/ui/ (50+ shadcn components)

Styles to Export:
  ☐ globals.css (CSS variables, animations, utilities)
  ☐ index.css (Tailwind imports)
  ☐ tailwind.config.js (Theme configuration)

Pages to Export:
  ☐ All 20+ page files from pages/ directory

Integrations:
  ☐ All backend functions from functions/ directory
  ☐ Entity schemas from entities/ directory
  ☐ API client setup from api/base44Client.js

════════════════════════════════════════════════════════════════════════════════════

SAVE THIS FILE AS: ASSETS_INVENTORY.md in your exported project
*/