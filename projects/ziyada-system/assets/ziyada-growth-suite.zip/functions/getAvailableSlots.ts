import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// Available times per day (9am-5pm, 1h slots, Sun-Thu)
const ALL_SLOTS = ["09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00"];
const WORKING_DAYS = [0,1,2,3,4]; // Sun=0, Mon=1, Tue=2, Wed=3, Thu=4

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { date } = await req.json();

    if (!date) return Response.json({ error: "date required" }, { status: 400 });

    const d = new Date(date);
    const dayOfWeek = d.getDay();
    if (!WORKING_DAYS.includes(dayOfWeek)) {
      return Response.json({ available_slots: [], reason: "not_working_day" });
    }

    // Get already booked slots for this date
    const existing = await base44.asServiceRole.entities.Booking.filter({ booking_date: date, status: "confirmed" });
    const bookedTimes = existing.map(b => b.booking_time);
    const available_slots = ALL_SLOTS.filter(s => !bookedTimes.includes(s));

    return Response.json({ available_slots, date });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});