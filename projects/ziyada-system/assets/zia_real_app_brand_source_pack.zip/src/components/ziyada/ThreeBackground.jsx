import { useEffect, useRef } from "react";
import * as THREE from "three";

export default function ThreeBackground({ theme = "dark" }) {
  const mountRef = useRef(null);
  const themeRef = useRef(theme);
  themeRef.current = theme;

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    /* ── Renderer ── */
    const W = window.innerWidth, H = window.innerHeight;
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mount.appendChild(renderer.domElement);

    // --- Export Button for PNG ---
    if (!document.getElementById("ziyada-export-btn")) {
      const btn = document.createElement("button");
      btn.id = "ziyada-export-btn";
      btn.innerText = "Export Brain Mesh PNG";
      btn.style.position = "fixed";
      btn.style.top = "20px";
      btn.style.right = "20px";
      btn.style.zIndex = 99999;
      btn.style.padding = "12px 20px";
      btn.style.background = "#3b82f6";
      btn.style.color = "#fff";
      btn.style.border = "none";
      btn.style.borderRadius = "8px";
      btn.style.fontWeight = "bold";
      btn.style.cursor = "pointer";
      btn.onclick = () => {
        const dataURL = renderer.domElement.toDataURL("image/png");
        const a = document.createElement("a");
        a.href = dataURL;
        a.download = "ziyada-brain-mesh.png";
        a.click();
      };
      document.body.appendChild(btn);
    }

    /* ── Scene & Camera ── */
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60, W / H, 0.1, 1000);
    camera.position.z = 30;

    /* ── Mouse tracking ── */
    const mouse   = { x: 0, y: 0 };
    const target  = { x: 0, y: 0 };
    // scroll: track normalized scroll progress (0-1)
    let scrollY   = 0;
    let targetScrollY = 0;

    const onMouseMove = (e) => {
      target.x = (e.clientX / window.innerWidth  - 0.5) * 2;
      target.y = (e.clientY / window.innerHeight - 0.5) * 2;
    };
    const onScroll = () => {
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      targetScrollY = maxScroll > 0 ? window.scrollY / maxScroll : 0;
    };
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("scroll", onScroll, { passive: true });

    /* ── Custom cursor ── */
    const makeCursorEl = (id, css) => {
      if (document.getElementById(id)) document.getElementById(id).remove();
      const el = document.createElement("div");
      el.id = id; el.style.cssText = css;
      document.body.appendChild(el);
      return el;
    };
    const dot = makeCursorEl("z-cursor-dot", `
      position:fixed;pointer-events:none;z-index:9999;
      width:7px;height:7px;border-radius:50%;
      background:#3b82f6;transform:translate(-50%,-50%);top:0;left:0;
      box-shadow:0 0 10px rgba(59,130,246,.9),0 0 22px rgba(59,130,246,.5);
      transition:width .18s,height .18s,background .18s,box-shadow .18s;
    `);
    const ring = makeCursorEl("z-cursor-ring", `
      position:fixed;pointer-events:none;z-index:9998;
      width:32px;height:32px;border-radius:50%;
      border:1.5px solid rgba(59,130,246,.55);
      transform:translate(-50%,-50%);top:0;left:0;
      transition:width .14s,height .14s,border-color .14s;
    `);

    let cx = W / 2, cy = H / 2, rx = cx, ry = cy;
    const onMouseMoveDOM = (e) => { cx = e.clientX; cy = e.clientY; };
    window.addEventListener("mousemove", onMouseMoveDOM);

    const onEnter = () => {
      dot.style.width="14px"; dot.style.height="14px";
      dot.style.background="#8b5cf6";
      dot.style.boxShadow="0 0 14px rgba(139,92,246,.9),0 0 28px rgba(139,92,246,.5)";
      ring.style.width="52px"; ring.style.height="52px";
      ring.style.borderColor="rgba(139,92,246,.6)";
    };
    const onLeave = () => {
      dot.style.width="7px"; dot.style.height="7px";
      dot.style.background="#3b82f6";
      dot.style.boxShadow="0 0 10px rgba(59,130,246,.9),0 0 22px rgba(59,130,246,.5)";
      ring.style.width="32px"; ring.style.height="32px";
      ring.style.borderColor="rgba(59,130,246,.55)";
    };
    const attachCursor = () => {
      document.querySelectorAll("a,button,[role=button],input,textarea,select").forEach(el => {
        el.removeEventListener("mouseenter", onEnter);
        el.removeEventListener("mouseleave", onLeave);
        el.addEventListener("mouseenter", onEnter);
        el.addEventListener("mouseleave", onLeave);
      });
    };
    attachCursor();
    const mutObs = new MutationObserver(attachCursor);
    mutObs.observe(document.body, { childList: true, subtree: true });

    /* ══ 3-D SCENE ══ */
    const BLUE   = 0x3b82f6;
    const PURPLE = 0x8b5cf6;

    // Brain core
    const coreGeo = new THREE.IcosahedronGeometry(6, 1);
    const coreMat = new THREE.MeshBasicMaterial({ color: BLUE, wireframe: true, transparent: true, opacity: 0.30 });
    const core = new THREE.Mesh(coreGeo, coreMat);
    scene.add(core);

    // Outer ring — TorusKnot (scroll-linked)
    const tkGeo = new THREE.TorusKnotGeometry(12, 3, 128, 16, 2, 3);
    const tkMat = new THREE.MeshBasicMaterial({ color: PURPLE, wireframe: true, transparent: true, opacity: 0.20 });
    const tk = new THREE.Mesh(tkGeo, tkMat);
    scene.add(tk);

    // 900 particles
    const PARTICLE_COUNT = 900;
    const pPos = new Float32Array(PARTICLE_COUNT * 3);
    for (let i = 0; i < PARTICLE_COUNT * 3; i++) pPos[i] = (Math.random() - 0.5) * 60;
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute("position", new THREE.BufferAttribute(pPos, 3));
    const pMat = new THREE.PointsMaterial({ color: BLUE, size: 0.12, transparent: true, opacity: 0.6 });
    const particles = new THREE.Points(pGeo, pMat);
    scene.add(particles);

    /* ── Animation loop ── */
    let raf;
    const clock = new THREE.Clock();

    const animate = () => {
      raf = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Smooth mouse lerp
      mouse.x += (target.x - mouse.x) * 0.05;
      mouse.y += (target.y - mouse.y) * 0.05;

      // Smooth scroll lerp
      scrollY += (targetScrollY - scrollY) * 0.04;

      // DOM cursor
      dot.style.left = cx + "px"; dot.style.top = cy + "px";
      rx += (cx - rx) * 0.1; ry += (cy - ry) * 0.1;
      ring.style.left = rx + "px"; ring.style.top = ry + "px";

      // Core — mouse-responsive
      core.rotation.x = elapsed * 0.18 + mouse.y * 0.3;
      core.rotation.y = elapsed * 0.22 + mouse.x * 0.3;

      // TorusKnot — cursor drag + slow scroll offset
      tk.rotation.x = elapsed * 0.12 + mouse.y * 0.25 + scrollY * Math.PI * 0.3;
      tk.rotation.y = elapsed * 0.16 + mouse.x * 0.25 + scrollY * Math.PI * 0.2;
      tk.rotation.z = scrollY * Math.PI * 0.4; // gentle tilt from scroll

      // Subtle scale on scroll
      const scaleTK = 1 + scrollY * 0.1;
      tk.scale.set(scaleTK, scaleTK, scaleTK);

      particles.rotation.y = elapsed * 0.03 + scrollY * 0.2;
      particles.rotation.x = scrollY * 0.1;

      // Theme opacity — nearly invisible in light mode
      const dark = themeRef.current !== "light";
      coreMat.opacity = dark ? 0.65 : 0.12;
      tkMat.opacity   = dark ? 0.50 : 0.08;
      pMat.opacity    = dark ? 0.90 : 0.15;

      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mousemove", onMouseMoveDOM);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
      mutObs.disconnect();
      ["z-cursor-dot", "z-cursor-ring"].forEach(id => document.getElementById(id)?.remove());
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, []);

  return (
    <div ref={mountRef} style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none" }} />
  );
}