# Corporate Design Kit (Open Source)

This package is designed for B2B/corporate usage inspired by Ziyada visual direction.

## Included

- backgrounds/: atmospheric corporate backgrounds (SVG + PNG)
- cards/: glass card components (SVG + PNG)
- frames/: presentation and media frames (SVG + PNG)
- icons/: reusable icon badges (SVG + PNG)
- patterns-minimal/: lighter/minimal repeating patterns (SVG + PNG)

## License

- CC0 1.0 (public domain dedication)
- Designers can use, edit, and distribute freely.

## Recommended use

- Use backgrounds as base layers.
- Stack frames/cards above backgrounds.
- Use icons for feature bullets and service tiles.
- Use patterns-minimal for stationery and social post textures.
